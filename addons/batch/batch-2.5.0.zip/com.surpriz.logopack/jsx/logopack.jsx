/*
 * Logo Pack - Surpriz
 * Moteur ExtendScript pour Adobe Illustrator (appele par le panneau CEP).
 *
 * Fichier volontairement en ASCII pur : les caracteres accentues sont
 * ecrits en \uXXXX pour ne pas dependre de l'encodage lu par ExtendScript.
 *
 * Toutes les fonctions publiques passent par SurprizLogoPack.api(nom, argsEncodes)
 * qui renvoie toujours une chaine JSON { ok: true|false, ... }.
 */
(function (G) {
    var LP = {};
    LP.version = '2.5.0';

    var TAG = 'LOGOPACK';
    var L_LOGOS = 'D\u00e9clinaisons (BATCH)';
    var L_FONDS = 'Fonds (BATCH)';
    var L_PREVIEW = 'Aper\u00e7u fond sombre (BATCH, non export\u00e9)';
    // Noms des versions precedentes (Logo Pack), toujours reconnus.
    var OLD_NAMES = {};
    OLD_NAMES[L_LOGOS] = 'D\u00e9clinaisons (Logo Pack)';
    OLD_NAMES[L_FONDS] = 'Fonds (Logo Pack)';
    OLD_NAMES[L_PREVIEW] = 'Aper\u00e7u fond sombre (Logo Pack, non export\u00e9)';
    var PREVIEW_HEX = '#3A3A3A';
    var CAPTURE_MAX_PPI = 2400;

    var job = null;     // travail de creation en cours
    // Source memorisee : le logo charge reste la source, quelle que soit la selection ensuite.
    var source = null;  // { doc, items, name }

    /* ------------------------------------------------------------------ */
    /* Utilitaires generaux                                                */
    /* ------------------------------------------------------------------ */

    function fail(code, detail) {
        var e = new Error(code);
        e.lpCode = code;
        e.lpDetail = detail || '';
        return e;
    }

    function indexOf(arr, v) {
        for (var i = 0; i < arr.length; i++) { if (arr[i] === v) { return i; } }
        return -1;
    }

    function pushUnique(arr, v) {
        if (indexOf(arr, v) < 0) { arr.push(v); }
    }

    function quote(s) {
        s = String(s);
        var out = '"';
        for (var i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            var code = s.charCodeAt(i);
            if (c === '"') { out += '\\"'; }
            else if (c === '\\') { out += '\\\\'; }
            else if (code < 32 || code > 126) {
                var h = code.toString(16);
                while (h.length < 4) { h = '0' + h; }
                out += '\\u' + h;
            } else { out += c; }
        }
        return out + '"';
    }

    function stringify(v) {
        if (v === null || v === undefined) { return 'null'; }
        var t = typeof v;
        if (t === 'number') { return isFinite(v) ? String(v) : 'null'; }
        if (t === 'boolean') { return v ? 'true' : 'false'; }
        if (t === 'string') { return quote(v); }
        if (v instanceof Array) {
            var a = [];
            for (var i = 0; i < v.length; i++) { a.push(stringify(v[i])); }
            return '[' + a.join(',') + ']';
        }
        var parts = [];
        for (var k in v) {
            if (v.hasOwnProperty(k) && typeof v[k] !== 'function') {
                parts.push(quote(k) + ':' + stringify(v[k]));
            }
        }
        return '{' + parts.join(',') + '}';
    }

    function activeDoc() {
        if (app.documents.length === 0) { throw fail('NO_DOC'); }
        return app.activeDocument;
    }

    function readNote(item) {
        try { return item.note || ''; } catch (e) { return ''; }
    }

    /* ------------------------------------------------------------------ */
    /* Bornes                                                              */
    /* ------------------------------------------------------------------ */

    function unionB(a, b) {
        if (!a) { return b ? [b[0], b[1], b[2], b[3]] : null; }
        if (!b) { return [a[0], a[1], a[2], a[3]]; }
        return [Math.min(a[0], b[0]), Math.max(a[1], b[1]), Math.max(a[2], b[2]), Math.min(a[3], b[3])];
    }

    function clipPathOf(group) {
        for (var i = 0; i < group.pageItems.length; i++) {
            var it = group.pageItems[i];
            if (it.typename === 'PathItem' && it.clipping) { return it; }
            if (it.typename === 'CompoundPathItem' && it.pathItems.length > 0 && it.pathItems[0].clipping) { return it; }
        }
        return null;
    }

    // Bornes visibles, en tenant compte des masques d'ecretage.
    function visBounds(item) {
        var t = item.typename;
        if (t === 'GroupItem') {
            if (item.clipped) {
                var cp = clipPathOf(item);
                if (cp) { return cp.geometricBounds; }
            }
            var b = null;
            for (var i = 0; i < item.pageItems.length; i++) {
                var it = item.pageItems[i];
                if (it.hidden) { continue; }
                b = unionB(b, visBounds(it));
            }
            return b;
        }
        if (t === 'PathItem' && item.guides) { return null; }
        try { return item.visibleBounds; } catch (e) { return item.geometricBounds; }
    }

    function boundsOf(items) {
        var b = null;
        for (var i = 0; i < items.length; i++) {
            if (items[i].hidden) { continue; }
            b = unionB(b, visBounds(items[i]));
        }
        return b;
    }

    function boundsIn(container) {
        var arr = [];
        for (var i = 0; i < container.pageItems.length; i++) { arr.push(container.pageItems[i]); }
        return boundsOf(arr);
    }

    function boxesOverlap(a, b) {
        for (var i = 0; i < a.length; i++) {
            for (var j = 0; j < b.length; j++) {
                var p = a[i], q = b[j];
                if (p[0] < q[2] && p[2] > q[0] && p[3] < q[1] && p[1] > q[3]) { return true; }
            }
        }
        return false;
    }

    /* ------------------------------------------------------------------ */
    /* Parcours                                                            */
    /* ------------------------------------------------------------------ */

    // Tous les objets descendants d'un objet (le parcours entre dans les groupes).
    function collect(item, out) {
        out.push(item);
        if (item.typename === 'GroupItem') {
            for (var i = 0; i < item.pageItems.length; i++) { collect(item.pageItems[i], out); }
        }
        return out;
    }

    function collectIn(container) {
        var out = [];
        for (var i = 0; i < container.pageItems.length; i++) { collect(container.pageItems[i], out); }
        return out;
    }

    function topItems(container) {
        var out = [];
        for (var i = 0; i < container.pageItems.length; i++) { out.push(container.pageItems[i]); }
        return out;
    }

    // Peintures (fond/contour) des chemins, pour l'analyse et la recoloration.
    function eachPaintable(items, fn) {
        for (var i = 0; i < items.length; i++) {
            var it = items[i];
            var t = it.typename;
            if (t === 'PathItem') {
                if (!it.clipping && !it.guides) { fn(it, 'path'); }
            } else if (t === 'CompoundPathItem') {
                if (it.pathItems.length > 0 && !it.pathItems[0].clipping) { fn(it, 'compound'); }
            } else if (t === 'TextFrame') {
                fn(it, 'text');
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* Couleurs                                                            */
    /* ------------------------------------------------------------------ */

    function isCMYKDoc(d) { return d.documentColorSpace === DocumentColorSpace.CMYK; }

    function makeRGB(r, g, b) { var c = new RGBColor(); c.red = r; c.green = g; c.blue = b; return c; }
    function makeCMYK(c, m, y, k) { var o = new CMYKColor(); o.cyan = c; o.magenta = m; o.yellow = y; o.black = k; return o; }
    function makeGray(g) { var o = new GrayColor(); o.gray = g; return o; }

    function blackOf(d) { return isCMYKDoc(d) ? makeCMYK(0, 0, 0, 100) : makeRGB(0, 0, 0); }
    function whiteOf(d) { return isCMYKDoc(d) ? makeCMYK(0, 0, 0, 0) : makeRGB(255, 255, 255); }

    function hexToRGB(hex) {
        var h = String(hex || '').replace('#', '');
        if (h.length === 3) { h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2); }
        if (h.length !== 6) { return [0, 0, 0]; }
        return [parseInt(h.substring(0, 2), 16), parseInt(h.substring(2, 4), 16), parseInt(h.substring(4, 6), 16)];
    }

    function rgbHex(r, g, b) {
        function h(v) {
            v = Math.max(0, Math.min(255, Math.round(v)));
            var s = v.toString(16);
            return s.length < 2 ? '0' + s : s;
        }
        return '#' + h(r) + h(g) + h(b);
    }

    function colorFromHex(d, hex) {
        var rgb = hexToRGB(hex);
        if (!isCMYKDoc(d)) { return makeRGB(rgb[0], rgb[1], rgb[2]); }
        var r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255;
        var k = 1 - Math.max(r, Math.max(g, b));
        if (k >= 0.999) { return makeCMYK(0, 0, 0, 100); }
        return makeCMYK((1 - r - k) / (1 - k) * 100, (1 - g - k) / (1 - k) * 100, (1 - b - k) / (1 - k) * 100, k * 100);
    }

    function labToRGB(L, a, b) {
        var fy = (L + 16) / 116, fx = fy + a / 500, fz = fy - b / 200;
        function inv(t) { return t > 0.206897 ? t * t * t : (t - 16 / 116) / 7.787; }
        var X = 0.95047 * inv(fx), Y = inv(fy), Z = 1.08883 * inv(fz);
        var rl = 3.2406 * X - 1.5372 * Y - 0.4986 * Z;
        var gl = -0.9689 * X + 1.8758 * Y + 0.0415 * Z;
        var bl = 0.0557 * X - 0.2040 * Y + 1.0570 * Z;
        function gam(v) { v = Math.max(0, Math.min(1, v)); return 255 * (v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055); }
        return [gam(rl), gam(gl), gam(bl)];
    }

    function toRGB(c) {
        if (!c) { return null; }
        switch (c.typename) {
            case 'RGBColor': return [c.red, c.green, c.blue];
            case 'CMYKColor':
                return [255 * (1 - c.cyan / 100) * (1 - c.black / 100), 255 * (1 - c.magenta / 100) * (1 - c.black / 100), 255 * (1 - c.yellow / 100) * (1 - c.black / 100)];
            case 'GrayColor':
                var v = 255 * (1 - c.gray / 100);
                return [v, v, v];
            case 'LabColor': return labToRGB(c.l, c.a, c.b);
            case 'SpotColor':
                var base = toRGB(c.spot.color);
                if (!base) { return null; }
                var t = c.tint / 100;
                return [255 - (255 - base[0]) * t, 255 - (255 - base[1]) * t, 255 - (255 - base[2]) * t];
        }
        return null;
    }

    function isWhite(c) {
        if (!c) { return false; }
        switch (c.typename) {
            case 'RGBColor': return c.red >= 250 && c.green >= 250 && c.blue >= 250;
            case 'CMYKColor': return c.cyan <= 1 && c.magenta <= 1 && c.yellow <= 1 && c.black <= 1;
            case 'GrayColor': return c.gray <= 1;
            case 'LabColor': return c.l >= 98 && Math.abs(c.a) <= 2 && Math.abs(c.b) <= 2;
            case 'SpotColor': return c.tint <= 1 || isWhite(c.spot.color);
        }
        return false;
    }

    function isPaint(c) {
        return c && c.typename !== 'NoColor';
    }

    function r2(v) { return Math.round(v * 100) / 100; }

    function colorKey(c) {
        switch (c.typename) {
            case 'RGBColor': return 'RGB:' + r2(c.red) + ',' + r2(c.green) + ',' + r2(c.blue);
            case 'CMYKColor': return 'CMYK:' + r2(c.cyan) + ',' + r2(c.magenta) + ',' + r2(c.yellow) + ',' + r2(c.black);
            case 'GrayColor': return 'GRAY:' + r2(c.gray);
            case 'LabColor': return 'LAB:' + r2(c.l) + ',' + r2(c.a) + ',' + r2(c.b);
            case 'SpotColor': return 'SPOT:' + c.spot.name + '|' + r2(c.tint);
        }
        return null;
    }

    function colorLabel(c) {
        switch (c.typename) {
            case 'RGBColor': return 'R' + Math.round(c.red) + ' V' + Math.round(c.green) + ' B' + Math.round(c.blue);
            case 'CMYKColor': return 'C' + Math.round(c.cyan) + ' M' + Math.round(c.magenta) + ' J' + Math.round(c.yellow) + ' N' + Math.round(c.black);
            case 'GrayColor': return 'Gris ' + Math.round(c.gray) + ' %';
            case 'LabColor': return 'Lab ' + Math.round(c.l) + ' ' + Math.round(c.a) + ' ' + Math.round(c.b);
            case 'SpotColor': return c.spot.name + (c.tint < 99.5 ? ' ' + Math.round(c.tint) + ' %' : '');
        }
        return '';
    }

    function colorFromKey(d, key, fallbackHex) {
        try {
            var p = key.indexOf(':');
            var type = key.substring(0, p);
            var rest = key.substring(p + 1);
            if (type === 'SPOT') {
                var bar = rest.lastIndexOf('|');
                var sp = d.spots.getByName(rest.substring(0, bar));
                var sc = new SpotColor();
                sc.spot = sp;
                sc.tint = parseFloat(rest.substring(bar + 1));
                return sc;
            }
            var v = rest.split(',');
            for (var i = 0; i < v.length; i++) { v[i] = parseFloat(v[i]); }
            if (type === 'RGB') { return makeRGB(v[0], v[1], v[2]); }
            if (type === 'CMYK') { return makeCMYK(v[0], v[1], v[2], v[3]); }
            if (type === 'GRAY') { return makeGray(v[0]); }
            if (type === 'LAB') { var l = new LabColor(); l.l = v[0]; l.a = v[1]; l.b = v[2]; return l; }
        } catch (e) { /* on retombe sur l'hexa */ }
        return colorFromHex(d, fallbackHex);
    }

    /* ------------------------------------------------------------------ */
    /* Selection                                                           */
    /* ------------------------------------------------------------------ */

    function getSelection(d) {
        var s = d.selection;
        if (!s) { return []; }
        if (s.typename === 'TextRange') { throw fail('TEXT_EDITING'); }
        var out = [];
        for (var i = 0; i < s.length; i++) { out.push(s[i]); }
        return out;
    }

    function addColor(map, order, c, area) {
        if (!isPaint(c) || !(area > 0)) { return; }
        if (c.typename === 'GradientColor') {
            var st = c.gradient.gradientStops;
            for (var i = 0; i < st.length; i++) { addColor(map, order, st[i].color, area / st.length); }
            return;
        }
        var k = colorKey(c);
        if (!k) { return; }
        if (!map.hasOwnProperty(k)) {
            var rgb = toRGB(c);
            map[k] = { key: k, hex: rgb ? rgbHex(rgb[0], rgb[1], rgb[2]) : '#888888', area: 0, white: isWhite(c), label: colorLabel(c) };
            order.push(k);
        }
        map[k].area += area;
    }

    function pathArea(p) {
        try { return Math.abs(p.area); } catch (e) { return 0; }
    }

    function compoundArea(cp) {
        var a = 0;
        for (var i = 0; i < cp.pathItems.length; i++) {
            try { a += cp.pathItems[i].area; } catch (e) { /* rien */ }
        }
        return Math.abs(a);
    }

    function sourceAlive() {
        if (!source) { return false; }
        try {
            var n = source.doc.name;
            if (!n) { return false; }
            for (var i = 0; i < source.items.length; i++) {
                var it = source.items[i];
                if (!it.typename || !it.parent) { return false; }
                var gb = it.geometricBounds;
                if (!gb) { return false; }
            }
            return source.items.length > 0;
        } catch (e) {
            return false;
        }
    }

    function sourceName(items) {
        if (items.length === 1) {
            var n = '';
            try { n = items[0].name; } catch (e) { n = ''; }
            if (n) { return n; }
        }
        return '';
    }

    // Charge la selection courante comme source (bouton ou logo glisse depuis le document).
    LP.setSource = function () {
        var d = activeDoc();
        var sel = getSelection(d);
        if (!sel.length) { throw fail('NO_SELECTION'); }
        source = { doc: d, items: sel, name: sourceName(sel) };
        return LP.sourceInfo();
    };

    LP.clearSource = function () {
        source = null;
        return { ok: true };
    };

    LP.sourceInfo = function () {
        if (!sourceAlive()) {
            var lost = source !== null;
            source = null;
            return { ok: true, count: 0, lost: lost, colors: [], flags: {} };
        }
        var res = describeItems(source.doc, source.items);
        res.name = source.name;
        return res;
    };

    LP.selectionInfo = function () {
        var d = activeDoc();
        return describeItems(d, getSelection(d));
    };

    function describeItems(d, sel) {
        var res = { ok: true, count: sel.length, doc: d.name, colorSpace: isCMYKDoc(d) ? 'CMYK' : 'RGB', colors: [], flags: {} };
        if (!sel.length) { return res; }

        var b = boundsOf(sel);
        if (b) { res.w = b[2] - b[0]; res.h = b[1] - b[3]; }

        var all = [];
        for (var i = 0; i < sel.length && all.length < 4000; i++) { collect(sel[i], all); }

        var f = { text: false, raster: false, mesh: false, plugin: false, symbol: false, clip: false, gradient: false, white: false, stroke: false };
        var map = {}, order = [];
        for (var j = 0; j < all.length; j++) {
            var it = all[j];
            var t = it.typename;
            if (t === 'GroupItem' && it.clipped) { f.clip = true; }
            else if (t === 'RasterItem' || t === 'PlacedItem') { f.raster = true; }
            else if (t === 'MeshItem') { f.mesh = true; }
            else if (t === 'PluginItem' || t === 'GraphItem') { f.plugin = true; }
            else if (t === 'SymbolItem') { f.symbol = true; }
        }
        eachPaintable(all, function (it, kind) {
            if (kind === 'text') {
                f.text = true;
                try {
                    var tr = it.textRange;
                    var size = tr.characterAttributes.size || 12;
                    var n = Math.min(tr.length, 400);
                    var fc = tr.characterAttributes.fillColor;
                    addColor(map, order, fc, n * size * size * 0.35);
                    if (isWhite(fc)) { f.white = true; }
                } catch (e) { /* texte vide */ }
                return;
            }
            var p = kind === 'compound' ? it.pathItems[0] : it;
            var area = kind === 'compound' ? compoundArea(it) : pathArea(it);
            if (p.filled && isPaint(p.fillColor)) {
                if (p.fillColor.typename === 'GradientColor') { f.gradient = true; }
                if (isWhite(p.fillColor)) { f.white = true; }
                addColor(map, order, p.fillColor, area);
            }
            if (p.stroked && isPaint(p.strokeColor) && p.strokeWidth > 0) {
                f.stroke = true;
                if (isWhite(p.strokeColor)) { f.white = true; }
                var len = 0;
                try { len = (kind === 'compound') ? 0 : it.length; } catch (e2) { len = 0; }
                addColor(map, order, p.strokeColor, Math.max(len * p.strokeWidth, 1));
            }
        });

        var list = [];
        for (var k = 0; k < order.length; k++) { list.push(map[order[k]]); }
        list.sort(function (a, c) { return c.area - a.area; });
        for (var m = 0; m < list.length && m < 8; m++) {
            res.colors.push({ key: list[m].key, hex: list[m].hex, white: list[m].white, label: list[m].label, share: list[m].area });
        }
        res.flags = f;
        return res;
    }

    /* ------------------------------------------------------------------ */
    /* Calques                                                             */
    /* ------------------------------------------------------------------ */

    function findLayer(d, name) {
        var old = OLD_NAMES.hasOwnProperty(name) ? OLD_NAMES[name] : null;
        for (var i = 0; i < d.layers.length; i++) {
            var L = d.layers[i];
            if (L.name === name) { return L; }
            if (old && L.name === old) {
                try { L.name = name; } catch (e) { /* calque verrouille : on garde l'ancien nom */ }
                return L;
            }
        }
        return null;
    }

    function ensureLayers(d) {
        var pv = findLayer(d, L_PREVIEW);
        var fd = findLayer(d, L_FONDS);
        var lg = findLayer(d, L_LOGOS);
        if (!pv) { pv = d.layers.add(); pv.name = L_PREVIEW; }
        if (!fd) { fd = d.layers.add(); fd.name = L_FONDS; }
        if (!lg) { lg = d.layers.add(); lg.name = L_LOGOS; }
        var arr = [pv, fd, lg];
        for (var i = 0; i < arr.length; i++) {
            try { arr[i].locked = false; arr[i].visible = true; } catch (e) { /* rien */ }
        }
        try { pv.printable = false; } catch (e2) { /* rien */ }
        return { preview: pv, fonds: fd, logos: lg };
    }

    function ancestorLayers(item) {
        var out = [];
        var p = item.parent;
        while (p) {
            if (p.typename === 'Layer') { out.push(p); }
            if (p.typename === 'Document') { break; }
            p = p.parent;
        }
        return out;
    }

    // Duplique un objet meme s'il est verrouille/masque (ou son calque).
    function dupFree(item, target, place) {
        var lays = ancestorLayers(item);
        var states = [];
        for (var i = 0; i < lays.length; i++) {
            states.push([lays[i].locked, lays[i].visible]);
            lays[i].locked = false;
            lays[i].visible = true;
        }
        var wasLocked = item.locked, wasHidden = item.hidden;
        try {
            item.locked = false;
            item.hidden = false;
            var d = item.duplicate(target, place);
            try { d.locked = false; d.hidden = false; } catch (e) { /* rien */ }
            return d;
        } finally {
            try { item.hidden = wasHidden; item.locked = wasLocked; } catch (e2) { /* rien */ }
            for (var j = lays.length - 1; j >= 0; j--) {
                try { lays[j].visible = states[j][1]; lays[j].locked = states[j][0]; } catch (e3) { /* rien */ }
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* Operations sur les declinaisons                                     */
    /* ------------------------------------------------------------------ */

    function selectIn(d, container) {
        d.selection = null;
        var items = topItems(container);
        for (var i = 0; i < items.length; i++) {
            try { items[i].selected = true; } catch (e) { /* rien */ }
        }
    }

    function menu(cmd) {
        app.executeMenuCommand(cmd);
    }

    function outlineTexts(container, warns) {
        var all = collectIn(container);
        for (var i = 0; i < all.length; i++) {
            if (all[i].typename === 'TextFrame') {
                try { all[i].createOutline(); } catch (e) { pushUnique(warns, 'TEXT_OUTLINE'); }
            }
        }
    }

    function breakSymbols(container) {
        for (var guard = 0; guard < 200; guard++) {
            var all = collectIn(container);
            var found = null;
            for (var i = 0; i < all.length; i++) {
                if (all[i].typename === 'SymbolItem') { found = all[i]; break; }
            }
            if (!found) { return; }
            try { found.breakLink(); } catch (e) { return; }
        }
    }

    // Regroupe tout le contenu d'un sous-calque dans un seul groupe.
    function groupAll(sub) {
        var items = topItems(sub);
        if (items.length === 1 && items[0].typename === 'GroupItem') { return items[0]; }
        var g = sub.groupItems.add();
        for (var i = items.length - 1; i >= 0; i--) {
            items[i].move(g, ElementPlacement.PLACEATBEGINNING);
        }
        return g;
    }

    function hasWhitePaint(container) {
        var found = false;
        eachPaintable(collectIn(container), function (it, kind) {
            if (found) { return; }
            if (kind === 'text') {
                try { if (isWhite(it.textRange.characterAttributes.fillColor)) { found = true; } } catch (e) { /* rien */ }
                return;
            }
            var p = kind === 'compound' ? it.pathItems[0] : it;
            if ((p.filled && isWhite(p.fillColor)) || (p.stroked && isWhite(p.strokeColor))) { found = true; }
        });
        return found;
    }

    function complexity(container) {
        var all = collectIn(container);
        var r = { clip: false, raster: false, mesh: false, plugin: false };
        for (var i = 0; i < all.length; i++) {
            var t = all[i].typename;
            if (t === 'GroupItem' && all[i].clipped) { r.clip = true; }
            else if (t === 'RasterItem' || t === 'PlacedItem') { r.raster = true; }
            else if (t === 'MeshItem') { r.mesh = true; }
            else if (t === 'PluginItem' || t === 'GraphItem') { r.plugin = true; }
        }
        return r;
    }

    function paintStats(container) {
        var s = { colored: 0, count: 0, whiteBoxes: [], coloredBoxes: [] };
        eachPaintable(collectIn(container), function (it, kind) {
            if (kind === 'text') { return; }
            var p = kind === 'compound' ? it.pathItems[0] : it;
            if (!p.filled || !isPaint(p.fillColor)) { return; }
            s.count++;
            var gb = it.geometricBounds;
            if (isWhite(p.fillColor)) { s.whiteBoxes.push(gb); }
            else {
                s.coloredBoxes.push(gb);
                s.colored += (kind === 'compound') ? compoundArea(it) : pathArea(it);
            }
        });
        return s;
    }

    function outlineStrokes(d, container) {
        var targets = [];
        eachPaintable(collectIn(container), function (it, kind) {
            if (kind === 'text') { return; }
            var p = kind === 'compound' ? it.pathItems[0] : it;
            if (p.stroked && isPaint(p.strokeColor) && p.strokeWidth > 0) { targets.push(it); }
        });
        if (!targets.length) { return; }
        d.selection = null;
        for (var i = 0; i < targets.length; i++) {
            try { targets[i].selected = true; } catch (e) { /* rien */ }
        }
        menu('OffsetPath v22');
        d.selection = null;
    }

    function removeEmptyGroups(container) {
        var all = collectIn(container);
        for (var i = all.length - 1; i >= 0; i--) {
            try {
                if (all[i].typename === 'GroupItem' && all[i].pageItems.length === 0) { all[i].remove(); }
            } catch (e) { /* deja supprime */ }
        }
    }

    // Evide les parties blanches : Pathfinder > Fusion, puis suppression des formes blanches.
    // Renvoie true (ok), false (echec, a refaire sans evidement) ou 'empty' (logo tout blanc).
    function knockout(d, sub) {
        outlineStrokes(d, sub);
        var before = paintStats(sub);
        if (!before.whiteBoxes.length) { return true; }
        var expectCut = boxesOverlap(before.whiteBoxes, before.coloredBoxes);

        var g = groupAll(sub);
        d.selection = null;
        g.selected = true;
        menu('Live Pathfinder Merge');
        menu('expandStyle');
        d.selection = null;

        // Si la Fusion n'a rien fait (commande indisponible...), les formes sont strictement
        // identiques : on le detecte pour ne pas supprimer les blancs sans avoir decoupe.
        var after = paintStats(sub);
        var unchanged = after.count === before.count &&
            Math.abs(after.colored - before.colored) <= before.colored * 1e-6 + 1e-6;
        if (expectCut && unchanged) { return false; }

        var kept = 0;
        var all = collectIn(sub);
        for (var i = all.length - 1; i >= 0; i--) {
            var it = all[i];
            try {
                if (it.typename === 'PathItem') {
                    if (it.clipping || it.guides) { continue; }
                    if (!it.filled || !isPaint(it.fillColor) || isWhite(it.fillColor)) { it.remove(); } else { kept++; }
                } else if (it.typename === 'CompoundPathItem') {
                    var p0 = it.pathItems.length ? it.pathItems[0] : null;
                    if (!p0 || !p0.filled || !isPaint(p0.fillColor) || isWhite(p0.fillColor)) { it.remove(); } else { kept++; }
                }
            } catch (e) { /* deja supprime */ }
        }
        removeEmptyGroups(sub);
        return kept > 0 ? true : 'empty';
    }

    // Deverrouille tout le contenu d'une declinaison (les formes verrouillees refusent la recoloration).
    function unlockAll(container) {
        var all = collectIn(container);
        for (var i = 0; i < all.length; i++) {
            try { if (all[i].locked) { all[i].locked = false; } } catch (e) { /* rien */ }
        }
    }

    function countType(container, typename) {
        var all = collectIn(container), n = 0;
        for (var i = 0; i < all.length; i++) { if (all[i].typename === typename) { n++; } }
        return n;
    }

    // Peinture dynamique, degrades de formes, enveloppes : objets que le script ne peut pas
    // recolorer directement. On les decompose en formes simples.
    var EXPANDERS = ['Expand Planet X', 'Path Blend Expand', 'Expand Envelope'];
    function expandSpecial(d, sub) {
        for (var guard = 0; guard < 60; guard++) {
            var all = collectIn(sub), target = null;
            for (var i = 0; i < all.length; i++) {
                if (all[i].typename === 'PluginItem') { target = all[i]; break; }
            }
            if (!target) { return true; }
            var before = countType(sub, 'PluginItem');
            d.selection = null;
            try { target.selected = true; } catch (e) { return false; }
            for (var c = 0; c < EXPANDERS.length; c++) {
                try { menu(EXPANDERS[c]); } catch (e2) { /* commande indisponible pour cet objet */ }
                if (countType(sub, 'PluginItem') < before) { break; }
            }
            d.selection = null;
            if (countType(sub, 'PluginItem') >= before) { return false; }
        }
        return true;
    }

    function paintsOf(it, kind) {
        if (kind === 'text') {
            var c = null;
            try { c = it.textRange.characterAttributes.fillColor; } catch (e) { c = null; }
            return { fill: isPaint(c) ? c : null, stroke: null };
        }
        var p = kind === 'compound' ? it.pathItems[0] : it;
        return {
            fill: (p.filled && isPaint(p.fillColor)) ? p.fillColor : null,
            stroke: (p.stroked && isPaint(p.strokeColor) && p.strokeWidth > 0) ? p.strokeColor : null
        };
    }

    function overlapRatio(a, b) {
        var w = Math.min(a[2], b[2]) - Math.max(a[0], b[0]);
        var h = Math.min(a[1], b[1]) - Math.max(a[3], b[3]);
        var area = (a[2] - a[0]) * (a[1] - a[3]);
        if (w <= 0 || h <= 0 || area <= 0) { return 0; }
        return (w * h) / area;
    }

    function setPaints(it, kind, color, onlyWhite) {
        if (kind === 'text') {
            try { it.textRange.characterAttributes.fillColor = color; } catch (e) { /* rien */ }
            return;
        }
        var paths = kind === 'compound' ? it.pathItems : [it];
        for (var i = 0; i < paths.length; i++) {
            var p = paths[i];
            if (p.filled && isPaint(p.fillColor) && (!onlyWhite || isWhite(p.fillColor))) { p.fillColor = color; }
            if (p.stroked && isPaint(p.strokeColor) && (!onlyWhite || isWhite(p.strokeColor))) { p.strokeColor = color; }
        }
    }

    // Une forme entierement blanche n'est un "vide" que si elle est posee sur une forme
    // de couleur (lettre blanche dans une pastille...). Sinon elle fait partie du logo :
    // on lui donne une couleur provisoire pour qu'elle soit recoloree comme le reste.
    function classifyWhites(sub, tmp) {
        var entries = [];
        eachPaintable(collectIn(sub), function (it, kind) {
            var pt = paintsOf(it, kind);
            if (!pt.fill && !pt.stroke) { return; }
            var fw = pt.fill ? isWhite(pt.fill) : true;
            var sw = pt.stroke ? isWhite(pt.stroke) : true;
            var box = null;
            try { box = it.visibleBounds; } catch (e) { box = it.geometricBounds; }
            entries.push({ it: it, kind: kind, box: box, allWhite: fw && sw, colored: !fw || !sw });
        });
        var standalone = 0;
        // L'ordre de parcours va du premier plan vers l'arriere-plan.
        for (var i = 0; i < entries.length; i++) {
            var e = entries[i];
            if (!e.allWhite) { continue; }
            var covered = 0;
            for (var j = i + 1; j < entries.length; j++) {
                if (entries[j].colored) { covered = Math.max(covered, overlapRatio(e.box, entries[j].box)); }
            }
            if (covered < 0.5) {
                setPaints(e.it, e.kind, tmp, true);
                standalone++;
            }
        }
        return standalone;
    }

    // Cle de la couleur telle qu'Illustrator la stocke une fois appliquee
    // (un Pantone ou un RVB peut etre converti dans un document CMJN, et inversement).
    function appliedKey(layer, color) {
        var r = layer.pathItems.rectangle(0, 0, 1, 1);
        try {
            r.stroked = false;
            r.filled = true;
            r.fillColor = color;
            return colorKey(r.fillColor);
        } finally {
            try { r.remove(); } catch (e) { /* rien */ }
        }
    }

    // Compte les peintures qui ne sont ni la couleur cible, ni un blanc volontairement garde.
    function strayPaints(container, mono, whiteTo) {
        var target = appliedKey(container, mono);
        var whiteKey = (whiteTo && whiteTo !== 'keep') ? appliedKey(container, whiteTo) : null;
        var n = 0;
        function bad(c) {
            if (!isPaint(c)) { return false; }
            var k = colorKey(c);
            if (k === target) { return false; }
            if (isWhite(c)) { return whiteKey !== null && k !== whiteKey; }
            return true;
        }
        eachPaintable(collectIn(container), function (it, kind) {
            try {
                if (kind === 'text') { if (bad(it.textRange.characterAttributes.fillColor)) { n++; } return; }
                var paths = kind === 'compound' ? it.pathItems : [it];
                for (var i = 0; i < paths.length; i++) {
                    var p = paths[i];
                    if ((p.filled && bad(p.fillColor)) || (p.stroked && bad(p.strokeColor))) { n++; break; }
                }
            } catch (e) { n++; }
        });
        return n + countType(container, 'PluginItem');
    }

    function paintTarget(current, mono, whiteTo) {
        if (!isPaint(current)) { return null; }
        if (isWhite(current)) {
            if (whiteTo === 'keep') { return null; }
            return whiteTo;
        }
        return mono;
    }

    function recolorPath(p, mono, whiteTo) {
        if (p.filled) {
            var f = paintTarget(p.fillColor, mono, whiteTo);
            if (f) { p.fillColor = f; }
        }
        if (p.stroked) {
            var s = paintTarget(p.strokeColor, mono, whiteTo);
            if (s) { p.strokeColor = s; }
        }
    }

    function recolorText(tf, mono, whiteTo) {
        var chars = tf.textRange.characters;
        if (chars.length > 500) {
            var ca = tf.textRange.characterAttributes;
            var t = paintTarget(ca.fillColor, mono, whiteTo);
            if (t) { ca.fillColor = t; }
            return;
        }
        for (var i = 0; i < chars.length; i++) {
            var a = chars[i].characterAttributes;
            var fc = paintTarget(a.fillColor, mono, whiteTo);
            if (fc) { a.fillColor = fc; }
            try {
                if (a.strokeWeight > 0) {
                    var sc = paintTarget(a.strokeColor, mono, whiteTo);
                    if (sc) { a.strokeColor = sc; }
                }
            } catch (e) { /* pas de contour */ }
        }
    }

    function recolorAll(container, mono, whiteTo, warns) {
        var all = collectIn(container);
        for (var i = 0; i < all.length; i++) {
            var it = all[i];
            try { it.opacity = 100; it.blendingMode = BlendModes.NORMAL; } catch (e) { /* rien */ }
            var t = it.typename;
            if (t === 'RasterItem' || t === 'PlacedItem') { pushUnique(warns, 'RASTER'); }
            else if (t === 'MeshItem') { pushUnique(warns, 'MESH'); }
            else if (t === 'PluginItem' || t === 'GraphItem') { pushUnique(warns, 'PLUGIN'); }
        }
        eachPaintable(all, function (it, kind) {
            try {
                if (kind === 'path') { recolorPath(it, mono, whiteTo); }
                else if (kind === 'compound') {
                    for (var k = 0; k < it.pathItems.length; k++) { recolorPath(it.pathItems[k], mono, whiteTo); }
                } else { recolorText(it, mono, whiteTo); }
            } catch (e) { pushUnique(warns, 'RECOLOR'); }
        });
    }

    function makeRect(layer, rect, color, name, note, locked) {
        var r = layer.pathItems.rectangle(rect[1], rect[0], rect[2] - rect[0], rect[1] - rect[3]);
        r.filled = true;
        r.fillColor = color;
        r.stroked = false;
        r.name = name;
        r.note = note;
        r.locked = locked !== false;
        return r;
    }

    function luminance(hex) {
        var c = hexToRGB(hex);
        return (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
    }

    function brandColor(d) {
        if (job.brand && job.brand.key) { return colorFromKey(d, job.brand.key, job.brand.hex); }
        return colorFromHex(d, job.brand ? job.brand.hex : '#000000');
    }

    function monoColor(d, row) {
        if (row === 'noir') { return blackOf(d); }
        if (row === 'blanc') { return whiteOf(d); }
        if (row === 'mono') { return brandColor(d); }
        return null;
    }

    function bgColor(d, col) {
        if (col === 'blanc') { return whiteOf(d); }
        if (col === 'noir') { return blackOf(d); }
        if (col === 'couleur') { return brandColor(d); }
        return null;
    }

    function clearContainer(sub) {
        var items = topItems(sub);
        for (var i = items.length - 1; i >= 0; i--) {
            try { items[i].locked = false; items[i].remove(); } catch (e) { /* rien */ }
        }
    }

    function fillVariant(d, sub, s, warns, allowKnockout) {
        // 1. Copie du logo source (meme ordre d'empilement) puis placement sur son plan de travail.
        //    Copie vers un autre document : Illustrator ne garde pas les memes coordonnees.
        //    On mesure donc la copie elle-meme pour connaitre le decalage entre les deux reperes.
        var dups = [];
        for (var i = job.src.length - 1; i >= 0; i--) {
            dups.push(dupFree(job.src[i], sub, ElementPlacement.PLACEATBEGINNING));
        }
        var raw = boundsOf(dups);
        var ox = raw ? raw[0] - job.srcRaw[0] : 0;
        var oy = raw ? raw[1] - job.srcRaw[1] : 0;
        var dx = (s.rect[0] + s.rect[2]) / 2 - ((job.mb[0] + job.mb[2]) / 2 + ox);
        var dy = (s.rect[1] + s.rect[3]) / 2 - ((job.mb[1] + job.mb[3]) / 2 + oy);
        for (var k = 0; k < dups.length; k++) { dups[k].translate(dx, dy); }

        var row = s.row;
        var isMono = (row === 'noir' || row === 'blanc' || row === 'mono');
        var wantKO = isMono && job.whiteMode === 'knockout' && allowKnockout;

        unlockAll(sub);
        if (job.outlineText || wantKO) { outlineTexts(sub, warns); }

        if (row === 'gris') {
            selectIn(d, sub);
            try { menu('Colors7'); } catch (e) { pushUnique(warns, 'GRAY_FAIL'); }
            d.selection = null;
            return;
        }
        if (!isMono) { return; }

        breakSymbols(sub);
        selectIn(d, sub);
        try { menu('expandStyle'); } catch (e2) { /* rien a developper */ }
        d.selection = null;
        unlockAll(sub);
        if (!expandSpecial(d, sub)) { pushUnique(warns, 'PLUGIN'); }

        var mono = monoColor(d, row);
        var bg = bgColor(d, s.col);
        var koDone = false;

        // Formes blanches qui font partie du logo (pas posees sur une couleur) : couleur provisoire.
        classifyWhites(sub, colorFromHex(d, '#808080'));

        if (wantKO && hasWhitePaint(sub)) {
            var cx = complexity(sub);
            if (cx.clip || cx.raster || cx.mesh || cx.plugin) {
                pushUnique(warns, cx.clip ? 'KO_CLIP' : 'KO_COMPLEX');
            } else {
                var r = false;
                try { r = knockout(d, sub); } catch (e3) { r = false; }
                if (r === true) { koDone = true; }
                else {
                    clearContainer(sub);
                    pushUnique(warns, r === 'empty' ? 'KO_EMPTY' : 'KO_FAIL');
                    fillVariant(d, sub, s, warns, false);
                    return;
                }
            }
        }

        var whiteTo;
        if (job.whiteMode === 'fill') { whiteTo = mono; }
        else if (job.whiteMode === 'keep') { whiteTo = 'keep'; }
        else if (koDone) { whiteTo = mono; }
        else if (bg) { whiteTo = bg; }
        else {
            whiteTo = 'keep';
            if (hasWhitePaint(sub)) { pushUnique(warns, 'WHITE_KEPT'); }
        }
        recolorAll(sub, mono, whiteTo, warns);

        // Controle : toutes les formes doivent avoir la couleur cible. Deuxieme passe si besoin.
        if (strayPaints(sub, mono, whiteTo) > 0) {
            unlockAll(sub);
            recolorAll(sub, mono, whiteTo, warns);
            var left = strayPaints(sub, mono, whiteTo);
            if (left > 0) { pushUnique(warns, 'RECOLOR_PARTIAL:' + left); }
        }
    }

    /* ------------------------------------------------------------------ */
    /* Creation : prepare / build / finish                                 */
    /* ------------------------------------------------------------------ */

    function measure(d, items, outline) {
        var L = d.layers.add();
        L.name = 'BATCH (mesure temporaire)';
        try {
            for (var i = items.length - 1; i >= 0; i--) { dupFree(items[i], L, ElementPlacement.PLACEATBEGINNING); }
            if (outline) { outlineTexts(L, []); }
            return boundsIn(L);
        } finally {
            try { L.remove(); } catch (e) { /* rien */ }
        }
    }

    function artboardsUnion(d) {
        var u = null;
        for (var i = 0; i < d.artboards.length; i++) { u = unionB(u, d.artboards[i].artboardRect); }
        return u;
    }

    function placeArtboards(d, specs, startL, startT, W, H, gap, reuseFirst) {
        var added = [];
        try {
            for (var k = 0; k < specs.length; k++) {
                var s = specs[k];
                var L = startL + s.ci * (W + gap);
                var T = startT - s.ri * (H + gap);
                var rect = [L, T, L + W, T - H];
                var ab;
                if (reuseFirst && k === 0) {
                    ab = d.artboards[0];
                    ab.artboardRect = rect;
                } else {
                    ab = d.artboards.add(rect);
                    added.push(ab);
                }
                ab.name = s.name;
                s.rect = rect;
            }
            return true;
        } catch (e) {
            for (var j = added.length - 1; j >= 0; j--) {
                try { added[j].remove(); } catch (e2) { /* rien */ }
            }
            return false;
        }
    }

    LP.prepare = function (a) {
        if (!sourceAlive()) { source = null; throw fail('NO_SOURCE'); }
        var d = source.doc;
        var sel = source.items;
        if (!a.variants || !a.variants.length) { throw fail('NO_VARIANT'); }
        app.activeDocument = d;

        var srcRaw = boundsOf(sel);
        var mb = measure(d, sel, !!a.outlineText);
        if (!mb || (mb[2] - mb[0]) < 0.01 || (mb[1] - mb[3]) < 0.01) { throw fail('EMPTY_BOUNDS'); }
        var w = mb[2] - mb[0], h = mb[1] - mb[3];
        var pad = Math.max(0, Number(a.margin) || 0) / 100 * Math.min(w, h);
        var W = Math.ceil(w + 2 * pad), H = Math.ceil(h + 2 * pad);
        var gap = Math.max(36, Math.round(0.2 * Math.max(W, H)));

        // Grille : une ligne par couleur de logo, dans l'ordre recu.
        var specs = [], rowOf = {}, rowCount = 0, colCount = {};
        var runId = new Date().getTime().toString(36);
        for (var i = 0; i < a.variants.length; i++) {
            var v = a.variants[i];
            if (!rowOf.hasOwnProperty(v.row)) { rowOf[v.row] = rowCount++; colCount[v.row] = 0; }
            specs.push({ row: v.row, col: v.col, name: v.name, ri: rowOf[v.row], ci: colCount[v.row]++, id: runId + '-' + i });
        }

        var target = d, created = false, initialLayer = null;
        if (a.dest === 'new') {
            target = app.documents.add(d.documentColorSpace, W, H);
            created = true;
            initialLayer = target.layers[0];
        }

        // Noms uniques parmi les plans de travail existants.
        var taken = [];
        for (var n = 0; n < target.artboards.length; n++) { taken.push(target.artboards[n].name); }
        for (var s1 = 0; s1 < specs.length; s1++) {
            var base = specs[s1].name, nm = base, c = 2;
            while (indexOf(taken, nm) >= 0) { nm = base + '-' + (c++); }
            specs[s1].name = nm;
            taken.push(nm);
        }

        var ok;
        if (created) {
            var r0 = target.artboards[0].artboardRect;
            ok = placeArtboards(target, specs, r0[0], r0[1], W, H, gap, true);
        } else {
            var u = artboardsUnion(target);
            ok = placeArtboards(target, specs, u[0], u[3] - gap * 2, W, H, gap, false) ||
                 placeArtboards(target, specs, u[2] + gap * 2, u[1], W, H, gap, false);
        }
        if (!ok) {
            if (created) { try { target.close(SaveOptions.DONOTSAVECHANGES); } catch (e) { /* rien */ } }
            throw fail('CANVAS');
        }

        ensureLayers(target);

        job = {
            src: sel, srcDoc: d, target: target, created: created, initialLayer: initialLayer,
            specs: specs, mb: mb, srcRaw: srcRaw, outlineText: !!a.outlineText, whiteMode: a.whiteMode || 'knockout',
            brand: a.brand || { hex: '#000000', key: null },
            lockBg: a.lockBg !== false
        };

        var names = [];
        for (var q = 0; q < specs.length; q++) { names.push(specs[q].name); }
        return { ok: true, count: specs.length, names: names, w: W, h: H };
    };

    LP.build = function (a) {
        if (!job) { throw fail('NO_JOB'); }
        var s = job.specs[a.i];
        if (!s) { throw fail('NO_JOB'); }
        var d = job.target;
        app.activeDocument = d;
        var warns = [];
        var L = ensureLayers(d);

        var sub = L.logos.layers.add();
        sub.name = s.name;
        try { sub.zOrder(ZOrderMethod.SENDTOBACK); } catch (e) { /* ordre cosmetique */ }

        fillVariant(d, sub, s, warns, true);

        if (s.col !== 'transparent') {
            makeRect(L.fonds, s.rect, bgColor(d, s.col), 'Fond ' + s.name, TAG + '|bg|' + s.id, job.lockBg);
        } else if (s.row === 'blanc' || (s.row === 'mono' && luminance(job.brand.hex) > 0.8)) {
            makeRect(L.preview, s.rect, colorFromHex(d, PREVIEW_HEX), 'Aper\u00e7u ' + s.name, TAG + '|preview|' + s.id, job.lockBg);
        }

        var g = groupAll(sub);
        g.name = s.name;
        g.note = TAG + '|logo|' + s.id + '|' + s.row + '|' + s.col;
        d.selection = null;
        return { ok: true, name: s.name, warnings: warns };
    };

    LP.finish = function () {
        if (!job) { return { ok: true }; }
        var d = job.target;
        try {
            if (job.created && job.initialLayer &&
                job.initialLayer.pageItems.length === 0 && job.initialLayer.layers.length === 0) {
                job.initialLayer.remove();
            }
        } catch (e) { /* rien */ }
        try { d.selection = null; } catch (e2) { /* rien */ }
        try { menu('fitall'); } catch (e3) { /* rien */ }
        var r = { ok: true, created: job.created, count: job.specs.length };
        job = null;
        return r;
    };

    /* ------------------------------------------------------------------ */
    /* Inventaire, suppression                                             */
    /* ------------------------------------------------------------------ */

    function eachLayer(container, fn) {
        for (var i = 0; i < container.layers.length; i++) {
            var L = container.layers[i];
            fn(L);
            eachLayer(L, fn);
        }
    }

    function scanTagged(d) {
        var res = { logos: [], bg: {}, preview: {}, all: [] };
        eachLayer(d, function (L) {
            for (var i = 0; i < L.pageItems.length; i++) {
                var it = L.pageItems[i];
                var n = readNote(it);
                if (n.indexOf(TAG + '|') !== 0) { continue; }
                var p = n.split('|');
                res.all.push(it);
                if (p[1] === 'logo') { res.logos.push({ item: it, id: p[2], row: p[3], col: p[4] }); }
                else if (p[1] === 'bg') { res.bg[p[2]] = it; }
                else if (p[1] === 'preview') { res.preview[p[2]] = it; }
            }
        });
        return res;
    }

    function artboardAt(d, b) {
        if (!b) { return -1; }
        var cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
        var best = -1, bestArea = Infinity;
        for (var i = 0; i < d.artboards.length; i++) {
            var r = d.artboards[i].artboardRect;
            if (cx >= r[0] && cx <= r[2] && cy <= r[1] && cy >= r[3]) {
                var area = (r[2] - r[0]) * (r[1] - r[3]);
                if (area < bestArea) { best = i; bestArea = area; }
            }
        }
        return best;
    }

    function variantBounds(t, v) {
        // Le fond (s'il existe) couvre exactement le plan de travail : c'est le repere le plus fiable.
        var bg = t.bg[v.id] || t.preview[v.id];
        if (bg) { return bg.geometricBounds; }
        return visBounds(v.item);
    }

    LP.inventory = function () {
        if (app.documents.length === 0) { return { ok: true, count: 0, bgs: 0, bgLocked: null }; }
        var t = scanTagged(app.activeDocument);
        var n = 0, locked = 0;
        for (var k in t.bg) { if (t.bg.hasOwnProperty(k)) { n++; if (t.bg[k].locked) { locked++; } } }
        return { ok: true, count: t.logos.length, bgs: n, bgLocked: n ? locked === n : null };
    };

    // Verrouille ou deverrouille les fonds (et apercus) deja crees dans le document actif.
    LP.setBgLock = function (a) {
        var d = activeDoc();
        var t = scanTagged(d);
        var n = 0;
        var maps = [t.bg, t.preview];
        for (var m = 0; m < maps.length; m++) {
            for (var k in maps[m]) {
                if (maps[m].hasOwnProperty(k)) {
                    try { maps[m][k].locked = !!a.locked; n++; } catch (e) { /* rien */ }
                }
            }
        }
        return { ok: true, count: n, locked: !!a.locked };
    };

    LP.removeAll = function () {
        var d = activeDoc();
        var t = scanTagged(d);
        var abs = [];
        for (var i = 0; i < t.logos.length; i++) {
            var idx = artboardAt(d, variantBounds(t, t.logos[i]));
            if (idx >= 0) { pushUnique(abs, idx); }
        }
        abs.sort(function (x, y) { return y - x; });
        var removedAB = 0;
        for (var k = 0; k < abs.length; k++) {
            if (d.artboards.length > 1) {
                try { d.artboards[abs[k]].remove(); removedAB++; } catch (e) { /* rien */ }
            }
        }
        for (var j = t.all.length - 1; j >= 0; j--) {
            try { t.all[j].locked = false; t.all[j].remove(); } catch (e2) { /* rien */ }
        }
        var names = [L_LOGOS, L_FONDS, L_PREVIEW];  // findLayer reconnait aussi les anciens noms
        for (var n = 0; n < names.length; n++) {
            var L = findLayer(d, names[n]);
            if (!L) { continue; }
            try {
                L.locked = false;
                for (var s = L.layers.length - 1; s >= 0; s--) {
                    var sub = L.layers[s];
                    if (sub.pageItems.length === 0 && sub.layers.length === 0) { sub.locked = false; sub.remove(); }
                }
                if (L.pageItems.length === 0 && L.layers.length === 0 && d.layers.length > 1) { L.remove(); }
            } catch (e3) { /* rien */ }
        }
        return { ok: true, artboards: removedAB, variants: t.logos.length };
    };

    /* ------------------------------------------------------------------ */
    /* Logo depose dans le panneau                                         */
    /* ------------------------------------------------------------------ */

    LP.tempFolder = function () {
        return { ok: true, path: Folder.temp.fsName };
    };

    function isOwnLayer(L) {
        var n = L.name;
        return n === L_LOGOS || n === L_FONDS || n === L_PREVIEW ||
            n === OLD_NAMES[L_LOGOS] || n === OLD_NAMES[L_FONDS] || n === OLD_NAMES[L_PREVIEW];
    }

    // Importe un fichier vectoriel (SVG, AI, EPS, PDF) et le selectionne.
    LP.placeFile = function (a) {
        var f = new File(a.path);
        if (!f.exists) { throw fail('FILE_MISSING'); }
        var d, created = false;
        if (app.documents.length === 0) {
            d = app.documents.add(DocumentColorSpace.RGB, 600, 400);
            created = true;
        } else {
            d = app.activeDocument;
        }
        var L = d.activeLayer;
        if (!L || L.locked || !L.visible || isOwnLayer(L) || (L.parent && L.parent.typename === 'Layer' && isOwnLayer(L.parent))) {
            L = findLayer(d, 'Logo source');
            if (!L) { L = d.layers.add(); L.name = 'Logo source'; }
            L.locked = false;
            L.visible = true;
        }
        var g = L.groupItems.createFromFile(f);
        if (a.name) { g.name = a.name; }
        var b = visBounds(g);
        if (b) {
            var w = b[2] - b[0], h = b[1] - b[3];
            if (created) {
                var pad = Math.max(w, h) * 0.15;
                d.artboards[0].artboardRect = [b[0] - pad, b[1] + pad, b[2] + pad, b[3] - pad];
            } else {
                try {
                    var c = d.activeView.centerPoint;
                    g.translate(c[0] - (b[0] + b[2]) / 2, c[1] - (b[1] + b[3]) / 2);
                } catch (e) { /* on laisse l'objet ou il est */ }
            }
        }
        d.selection = null;
        g.selected = true;
        try { if (created) { menu('fitall'); } } catch (e2) { /* rien */ }
        source = { doc: d, items: [g], name: a.name || '' };
        return { ok: true, created: created };
    };

    /* ------------------------------------------------------------------ */
    /* Profils (fichier JSON dans les donnees utilisateur)                 */
    /* ------------------------------------------------------------------ */

    function profilesFile(folderName) {
        var dir = Folder.userData.fsName;
        var parts = ['Surpriz', folderName || 'BATCH'];
        for (var i = 0; i < parts.length; i++) {
            dir += '/' + parts[i];
            var f = new Folder(dir);
            if (!f.exists && !folderName) { f.create(); }
        }
        return new File(dir + '/profils.json');
    }

    LP.profilesRead = function () {
        var f = profilesFile();
        if (!f.exists) {
            var old = profilesFile('LogoPack');
            if (!old.exists) { return { ok: true, json: '[]', path: f.fsName }; }
            f = old;
        }
        f.encoding = 'UTF-8';
        if (!f.open('r')) { throw fail('PROFILE_READ'); }
        var s = f.read();
        f.close();
        return { ok: true, json: s || '[]', path: f.fsName };
    };

    LP.profilesWrite = function (a) {
        var f = profilesFile();
        f.encoding = 'UTF-8';
        f.lineFeed = 'Unix';
        if (!f.open('w')) { throw fail('PROFILE_WRITE'); }
        f.write(String(a.json || '[]'));
        f.close();
        return { ok: true, path: f.fsName };
    };

    // Miniature PNG de la selection, pour les apercus du panneau.
    var lastThumb = null;
    LP.thumbnail = function (a) {
        if (!sourceAlive()) { source = null; throw fail('NO_SOURCE'); }
        var d = source.doc;
        var b = boundsOf(source.items);
        if (!b) { throw fail('EMPTY_BOUNDS'); }
        var w = b[2] - b[0], h = b[1] - b[3];
        var size = (a && a.size) ? a.size : 180;
        var ppi = Math.max(72, Math.min(CAPTURE_MAX_PPI, 72 * size / Math.max(w, h, 0.01)));
        if (lastThumb) { try { lastThumb.remove(); } catch (e) { /* rien */ } }
        var f = new File(Folder.temp.fsName + '/surpriz_batch_apercu_' + new Date().getTime() + '.png');
        var o = new ImageCaptureOptions();
        o.resolution = ppi;
        o.antiAliasing = true;
        o.transparency = true;
        d.imageCapture(f, b, o);
        lastThumb = f;
        if (!f.exists) { throw fail('THUMB_FAIL'); }
        return { ok: true, path: f.fsName };
    };

    function describeColor(c) {
        var key = colorKey(c);
        if (!key) { throw fail('BAD_COLOR'); }
        var rgb = toRGB(c);
        return { ok: true, key: key, hex: rgb ? rgbHex(rgb[0], rgb[1], rgb[2]) : '#000000', label: colorLabel(c) };
    }

    // Ouvre le Selecteur de couleurs d'Illustrator. Annuler renvoie la couleur de depart :
    // on la compare pour savoir si l'utilisateur a annule.
    LP.pickColor = function (a) {
        var start;
        if (app.documents.length) {
            var d = app.activeDocument;
            start = a.key ? colorFromKey(d, a.key, a.hex) : colorFromHex(d, a.hex || '#000000');
        } else {
            var rgb = hexToRGB(a.hex || '#000000');
            start = makeRGB(rgb[0], rgb[1], rgb[2]);
        }
        var before = colorKey(start);
        var c = app.showColorPicker(start);
        if (!c || !isPaint(c) || colorKey(c) === before) { return { ok: false, code: 'CANCELLED' }; }
        return describeColor(c);
    };

    // Couleur de remplissage active d'Illustrator (celle de l'objet selectionne,
    // ou celle prise avec la Pipette).
    LP.fillColor = function () {
        var d = activeDoc();
        var c = null;
        var sel = d.selection;
        if (sel && sel.length === 1 && sel[0].typename === 'PathItem' && sel[0].filled) { c = sel[0].fillColor; }
        if (!c) { c = d.defaultFillColor; }
        if (!isPaint(c) || c.typename === 'GradientColor' || c.typename === 'PatternColor') { throw fail('NO_FILL'); }
        return describeColor(c);
    };

    LP.ping = function () {
        return { ok: true, version: LP.version, app: app.version };
    };

    /* ------------------------------------------------------------------ */
    /* Point d'entree unique                                               */
    /* ------------------------------------------------------------------ */

    var PUBLIC = ['ping', 'selectionInfo', 'thumbnail', 'prepare', 'build', 'finish', 'inventory', 'removeAll',
                  'tempFolder', 'placeFile', 'profilesRead', 'profilesWrite', 'setBgLock', 'pickColor', 'fillColor',
                  'setSource', 'sourceInfo', 'clearSource'];

    LP.api = function (name, enc) {
        var prevUI, prevCS, hasUI = false, hasCS = false;
        try {
            if (indexOf(PUBLIC, name) < 0) { throw fail('UNKNOWN_FN', name); }
            var args = enc ? eval('(' + decodeURIComponent(enc) + ')') : {};
            try { prevUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; hasUI = true; } catch (e1) { /* rien */ }
            try { prevCS = app.coordinateSystem; app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM; hasCS = true; } catch (e2) { /* rien */ }
            return stringify(LP[name](args));
        } catch (e) {
            return stringify({ ok: false, code: e.lpCode || 'ERROR', detail: e.lpDetail || '', message: String(e.message || e), line: e.line || null });
        } finally {
            try { if (hasUI) { app.userInteractionLevel = prevUI; } } catch (e3) { /* rien */ }
            try { if (hasCS) { app.coordinateSystem = prevCS; } } catch (e4) { /* rien */ }
        }
    };

    G.SurprizLogoPack = LP;
}($.global));
