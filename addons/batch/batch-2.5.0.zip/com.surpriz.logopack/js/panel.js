/* BATCH — logique du panneau (CEP, Chromium).
 * Parle au moteur ExtendScript via SurprizLogoPack.api(nom, argsEncodes).
 * Hors d'Illustrator (navigateur), un faux moteur permet de prévisualiser le panneau. */
(function () {
  'use strict';

  const host = window.__adobe_cep__;
  const IN_CEP = !!host;
  const VERSION = '2.5.0';
  const STORE_KEY = 'surpriz.logopack.v2';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const clone = o => JSON.parse(JSON.stringify(o));

  /* ---------------------------------------------------------------- */
  /* Vocabulaire                                                       */
  /* ---------------------------------------------------------------- */

  const ROWS = [
    { id: 'couleur', label: 'Couleur', long: 'Logo en couleur', fr: 'couleur', en: 'color' },
    { id: 'noir', label: 'Noir', long: 'Logo noir', fr: 'noir', en: 'black' },
    { id: 'blanc', label: 'Blanc', long: 'Logo blanc', fr: 'blanc', en: 'white' },
    { id: 'gris', label: 'Gris', long: 'Logo en niveaux de gris', fr: 'niveaux de gris', en: 'grayscale' },
    { id: 'mono', label: 'Uni', long: 'Logo uni couleur de marque', fr: 'monochrome', en: 'monochrome' }
  ];
  const COLS = [
    { id: 'transparent', label: 'Sans fond', long: 'sans fond', fr: 'sans fond', en: 'transparent' },
    { id: 'couleur', label: 'Fond coloré', long: 'sur fond coloré', fr: 'fond coloré', en: 'color bg' }
  ];
  const ROW = Object.fromEntries(ROWS.map(r => [r.id, r]));
  const COL = Object.fromEntries(COLS.map(c => [c.id, c]));
  const OFF = new Set(['mono|couleur']);
  const ALL_CELLS = ROWS.flatMap(r => COLS.map(c => r.id + '|' + c.id)).filter(k => !OFF.has(k));
  const ESSENTIEL = ['couleur|transparent', 'noir|transparent', 'blanc|transparent', 'blanc|couleur'];
  const DEFAULT_PATTERN = '{client}_{logo}_{couleur}_{fond}';
  const PROFILE_FIELDS = ['client', 'logo', 'brand', 'customColors', 'cells', 'lang', 'textCase', 'ascii', 'pattern', 'margin', 'whiteMode', 'outlineText', 'dest'];
  const VECTOR_EXT = ['svg', 'ai', 'eps', 'pdf'];

  const DEFAULTS = {
    profile: '',
    client: '', logo: 'logo',
    cells: ESSENTIEL.slice(),
    brand: { hex: '#ddff12', key: null, label: '', auto: true },
    customColors: [],
    margin: 10, whiteMode: 'knockout', outlineText: true, dest: 'current',
    pattern: DEFAULT_PATTERN, lang: 'fr', textCase: 'lower', ascii: true,
    settingsOpen: false, lockBg: true
  };
  const MARGIN_MAX = 50;
  const CUSTOM_MAX = 10;

  const MESSAGES = {
    NO_DOC: 'Ouvre un document, ou glisse un fichier de logo ici.',
    NO_SELECTION: 'Rien de sélectionné dans Illustrator : sélectionne ton logo, puis « Charger la sélection ».',
    NO_SOURCE: 'Aucun logo dans la source : glisse ton logo dans la zone Source, ou « Charger la sélection ».',
    TEXT_EDITING: 'Tu es en train d’éditer du texte : appuie sur Échap, puis sélectionne le logo entier.',
    EMPTY_BOUNDS: 'La sélection n’a pas de taille mesurable.',
    NO_VARIANT: 'Coche au moins une version.',
    CANVAS: 'Plus de place sur la zone de travail : dans Réglages, choisis « Nouveau » pour les planches.',
    NO_JOB: 'La génération a été interrompue. Relance-la.',
    NOT_LOADED: 'Le moteur de l’extension n’est pas chargé. Ferme le panneau et rouvre-le.',
    BRIDGE: 'Illustrator n’a pas répondu. Réessaie ; si ça persiste, ferme le panneau et rouvre-le.',
    THUMB_FAIL: 'Aperçu indisponible pour cette sélection.',
    FILE_MISSING: 'Le fichier déposé est introuvable. Réessaie.',
    BAD_FILE: 'Glisse un fichier vectoriel : SVG, AI, EPS ou PDF.',
    WRITE_FAIL: 'Impossible de copier le fichier déposé. Ouvre-le dans Illustrator puis sélectionne-le.',
    PROFILE_READ: 'Impossible de lire les profils enregistrés.',
    NO_FILL: 'Pas de couleur de remplissage unie dans Illustrator : prends une couleur à la Pipette (I) ou sélectionne un objet de couleur unie.',
    BAD_COLOR: 'Cette couleur ne peut pas être utilisée (dégradé ou motif).',
    PROFILE_WRITE: 'Impossible d’enregistrer le profil.'
  };

  const WARNINGS = {
    RASTER: 'Image matricielle : elle n’a pas été recolorée.',
    MESH: 'Filet de dégradé : il n’a pas été recoloré.',
    PLUGIN: 'Objet spécial (dégradé de formes, enveloppe…) : décompose-le avant (Objet › Décomposer).',
    KO_CLIP: 'Masque d’écrêtage : les blancs n’ont pas été évidés.',
    KO_COMPLEX: 'Image ou objet spécial dans le logo : les blancs n’ont pas été évidés.',
    KO_FAIL: 'Évidement impossible : les blancs prennent la couleur du fond, ou restent blancs sans fond.',
    KO_EMPTY: 'Le logo est entièrement blanc : rien à évider.',
    WHITE_KEPT: 'Blancs gardés (pas de fond pour les remplacer).',
    TEXT_OUTLINE: 'Un texte n’a pas pu être vectorisé (police manquante ?).',
    GRAY_FAIL: 'Conversion en niveaux de gris impossible.',
    RECOLOR: 'Un objet n’a pas pu être recoloré.',
    RECOLOR_PARTIAL: 'formes n’ont pas pu être recolorées (objet spécial ou protégé). Décompose-les (Objet › Décomposer) puis relance.'
  };

  const LOCK_ICON = on => '<svg aria-hidden="true"><use href="#i-' + (on ? 'lock' : 'unlock') + '"/></svg>';
  const METER_DOTS = 9;
  const BARS = 32;

  /* ---------------------------------------------------------------- */
  /* État                                                              */
  /* ---------------------------------------------------------------- */

  function sanitizeCells(cells) {
    return Array.isArray(cells) ? cells.filter(k => ALL_CELLS.includes(k)) : ESSENTIEL.slice();
  }

  function load() {
    try {
      const raw = JSON.parse(localStorage.getItem(STORE_KEY) || 'null') ||
        JSON.parse(localStorage.getItem('surpriz.logopack.v1') || '{}');
      const out = Object.assign(clone(DEFAULTS), raw, { brand: Object.assign({}, DEFAULTS.brand, raw.brand || {}) });
      out.cells = sanitizeCells(out.cells);
      return out;
    } catch (e) {
      return clone(DEFAULTS);
    }
  }
  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(st)); } catch (e) { /* stockage indisponible */ }
  }

  let st = load();
  let profiles = [];
  let sel = null;          // infos de sélection renvoyées par le moteur
  let selError = null;
  let thumbSig = '';
  let thumbImg = null;
  let processed = {};      // id de ligne -> dataURL de l'aperçu
  let srcLight = false;    // logo source surtout blanc
  let inventory = 0;
  let inventoryBgs = 0;
  let busy = false;
  let cssTint = false;     // aperçus teintés en CSS si le canvas n'est pas lisible
  let thumbRetry = 0;

  /* ---------------------------------------------------------------- */
  /* Pont avec Illustrator                                             */
  /* ---------------------------------------------------------------- */

  function evalScript(code) {
    return new Promise(resolve => {
      if (!IN_CEP) { setTimeout(() => resolve(Mock.eval(code)), 50); return; }
      host.evalScript(code, resolve);
    });
  }

  function extensionPath() {
    let p = decodeURI(host.getSystemPath('extension'));
    if (/^file:\/\/\/[A-Za-z]:/.test(p)) p = p.replace('file:///', '');
    else p = p.replace('file://', '');
    return p;
  }

  async function api(name, args, retried) {
    const enc = args === undefined ? '' : encodeURIComponent(JSON.stringify(args));
    const code = '(typeof SurprizLogoPack === "undefined") ? \'{"ok":false,"code":"NOT_LOADED"}\' : SurprizLogoPack.api("' + name + '","' + enc + '")';
    const raw = await evalScript(code);
    let res;
    try { res = JSON.parse(raw); } catch (e) { res = { ok: false, code: 'BRIDGE', message: String(raw) }; }
    if (res.code === 'NOT_LOADED' && IN_CEP && !retried) {
      const path = extensionPath().replace(/\\/g, '/') + '/jsx/logopack.jsx';
      await evalScript('$.evalFile("' + path.replace(/"/g, '\\"') + '")');
      return api(name, args, true);
    }
    return res;
  }

  function readImage(path) {
    try {
      const r = window.cep.fs.readFile(path, window.cep.encoding.Base64);
      if (r.err === 0) return 'data:image/png;base64,' + r.data;
    } catch (e) { /* cep.fs indisponible */ }
    return 'file:///' + encodeURI(path.replace(/\\/g, '/').replace(/^\/+/, ''));
  }

  /* ---------------------------------------------------------------- */
  /* Nommage                                                           */
  /* ---------------------------------------------------------------- */

  function slug(text) {
    let t = String(text || '').trim();
    if (st.ascii) {
      t = t.normalize('NFD').replace(/[̀-ͯ]/g, '')
        .replace(/ß/g, 'ss').replace(/æ/g, 'ae').replace(/Æ/g, 'AE').replace(/œ/g, 'oe').replace(/Œ/g, 'OE')
        .replace(/[’']/g, '');
    }
    t = t.replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, '-');
    if (st.textCase === 'lower') t = t.toLowerCase();
    else if (st.textCase === 'upper') t = t.toUpperCase();
    else t = t.toLowerCase().replace(/(^|[-_.])(\p{L})/gu, (m, a, b) => a + b.toUpperCase());
    return t.replace(/-+/g, '-').replace(/^-|-$/g, '');
  }

  function nameFor(row, col, n) {
    const tokens = {
      client: slug(st.client),
      logo: slug(st.logo),
      couleur: slug(ROW[row][st.lang]),
      fond: slug(COL[col][st.lang]),
      n: String(n).padStart(2, '0')
    };
    let out = (st.pattern || DEFAULT_PATTERN).replace(/\{(\w+)\}/g, (m, k) => (k in tokens ? tokens[k] : m));
    out = out.replace(/[\\/:*?"<>|]+/g, '-')
      .replace(/([_\-. ])[_\-. ]+/g, '$1')
      .replace(/^[_\-. ]+|[_\-. ]+$/g, '');
    return out || 'logo';
  }

  function variants() {
    const out = [];
    let n = 1;
    for (const r of ROWS) {
      for (const c of COLS) {
        const k = r.id + '|' + c.id;
        if (OFF.has(k) || !st.cells.includes(k)) continue;
        out.push({ row: r.id, col: c.id, name: nameFor(r.id, c.id, n++) });
      }
    }
    return out;
  }

  /* ---------------------------------------------------------------- */
  /* Aperçus                                                           */
  /* ---------------------------------------------------------------- */

  function hexRGB(hex) {
    const h = String(hex || '#000').replace('#', '');
    const f = h.length === 3 ? h.split('').map(x => x + x).join('') : h;
    return [parseInt(f.slice(0, 2), 16) || 0, parseInt(f.slice(2, 4), 16) || 0, parseInt(f.slice(4, 6), 16) || 0];
  }

  function luminance(hex) {
    const [r, g, b] = hexRGB(hex);
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  }

  function processThumbs() {
    processed = {};
    srcLight = false;
    if (!thumbImg) return;
    const w = thumbImg.naturalWidth, h = thumbImg.naturalHeight;
    if (!w || !h) return;
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    const cx = cv.getContext('2d');
    cx.drawImage(thumbImg, 0, 0);
    let src;
    cssTint = false;
    try { src = cx.getImageData(0, 0, w, h); } catch (e) {
      // Image non lisible par le canvas : on teinte les aperçus en CSS.
      cssTint = true;
      for (const r of ROWS) processed[r.id] = thumbImg.src;
      return;
    }
    processed.couleur = cv.toDataURL();

    // Le logo source est-il surtout clair ? (pour choisir le fond de l'aperçu)
    let lum = 0, wsum = 0;
    for (let i = 0; i < src.data.length; i += 16) {
      const a = src.data[i + 3] / 255;
      if (!a) continue;
      lum += a * (0.2126 * src.data[i] + 0.7152 * src.data[i + 1] + 0.0722 * src.data[i + 2]) / 255;
      wsum += a;
    }
    srcLight = wsum > 0 && lum / wsum > 0.82;

    const tints = { noir: [0, 0, 0], blanc: [255, 255, 255], mono: hexRGB(st.brand.hex) };
    for (const row of ['noir', 'blanc', 'gris', 'mono']) {
      const out = cx.createImageData(w, h);
      const s = src.data, o = out.data;
      for (let i = 0; i < s.length; i += 4) {
        const a = s[i + 3];
        if (!a) continue;
        if (row === 'gris') {
          const l = 0.299 * s[i] + 0.587 * s[i + 1] + 0.114 * s[i + 2];
          o[i] = o[i + 1] = o[i + 2] = l; o[i + 3] = a;
          continue;
        }
        const tint = tints[row];
        const wk = Math.max(0, Math.min(1, (Math.min(s[i], s[i + 1], s[i + 2]) - 205) / 40));
        if (wk > 0 && st.whiteMode !== 'fill') {
          if (st.whiteMode === 'knockout') {
            o[i] = tint[0]; o[i + 1] = tint[1]; o[i + 2] = tint[2]; o[i + 3] = a * (1 - wk);
          } else {
            o[i] = tint[0] + (255 - tint[0]) * wk;
            o[i + 1] = tint[1] + (255 - tint[1]) * wk;
            o[i + 2] = tint[2] + (255 - tint[2]) * wk;
            o[i + 3] = a;
          }
          continue;
        }
        o[i] = tint[0]; o[i + 1] = tint[1]; o[i + 2] = tint[2]; o[i + 3] = a;
      }
      cx.putImageData(out, 0, 0);
      processed[row] = cv.toDataURL();
    }
  }

  function fallbackMark(row) {
    const brand = st.brand.hex;
    const fills = {
      couleur: [brand, '#2b2b38'], noir: ['#000', '#000'], blanc: ['#fff', '#fff'],
      gris: ['#8a8a8a', '#3d3d3d'], mono: [brand, brand]
    }[row];
    return '<svg class="mark-fallback" viewBox="0 0 60 36" aria-hidden="true"><circle cx="15" cy="18" r="12" fill="' + fills[0] + '"/>' +
      '<rect x="31" y="11" width="27" height="5" rx="1" fill="' + fills[1] + '"/>' +
      '<rect x="31" y="20" width="18" height="5" rx="1" fill="' + fills[1] + '"/></svg>';
  }

  function isBlank(img) {
    try {
      const c = document.createElement('canvas');
      c.width = Math.min(img.naturalWidth, 160); c.height = Math.min(img.naturalHeight, 160);
      const x = c.getContext('2d');
      x.drawImage(img, 0, 0, c.width, c.height);
      const d = x.getImageData(0, 0, c.width, c.height).data;
      for (let i = 3; i < d.length; i += 4) if (d[i] > 8) return false;
      return true;
    } catch (e) { return false; }
  }

  async function loadThumb(size) {
    const r = await api('thumbnail', { size: size || 240 });
    const fail = () => {
      thumbImg = null; processed = {};
      renderSource(); renderMatrix();
      // Juste après un import, Illustrator n'a parfois pas fini : on réessaie une fois.
      if (thumbRetry < 1) { thumbRetry++; setTimeout(() => loadThumb(600), 500); }
    };
    if (!r.ok) { fail(); return; }
    const img = new Image();
    img.onload = () => {
      if (isBlank(img) && thumbRetry < 1) { thumbRetry++; loadThumb(600); return; }
      thumbImg = img; processThumbs(); renderSource(); renderMatrix();
    };
    img.onerror = fail;
    img.src = IN_CEP ? readImage(r.path) : r.dataUrl;
  }

  /* ---------------------------------------------------------------- */
  /* Rendu                                                             */
  /* ---------------------------------------------------------------- */

  function esc(s) {
    return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }
  function plural(n, one, many) { return n + ' ' + (n > 1 ? many : one); }
  function mm(pt) { return Math.round(pt * 25.4 / 72); }
  function hasSel() { return !!(sel && sel.count) && !selError; }

  function renderProfiles() {
    const current = profiles.some(p => p.name === st.profile) ? st.profile : '';
    $('#profile-current').textContent = current || 'Aucun profil';
    const items = [{ name: '', label: 'Aucun profil' }].concat(profiles.map(p => ({ name: p.name, label: p.name })));
    $('#profile-menu').innerHTML = items.map((it, i) => '<li role="option" data-name="' + esc(it.name) + '" id="pf-' + i + '"' +
      (it.name ? '' : ' class="muted"') + ' aria-selected="' + (it.name === current) + '">' + esc(it.label) + '</li>').join('');
    $('#profile-del').disabled = !current;
    const hint = $('#profile-hint');
    if (current && isDirty()) hint.textContent = 'Modifié : « Sauver » met à jour le profil.';
    else if (!profiles.length) hint.textContent = 'Sauve un profil par client : couleurs, versions et noms.';
    else hint.textContent = '';
    $('#profile-save').textContent = current && !isDirty() ? 'Sauvé' : 'Sauver';
    $('#profile-save').disabled = !!current && !isDirty();
    $('#scr-profil').textContent = current ? current + (isDirty() ? ' *' : '') : '—';
  }

  function renderSource() {
    const drop = $('#drop');
    const img = $('#src-img');
    const show = hasSel() && processed.couleur;
    drop.classList.toggle('has-logo', !!show);
    drop.classList.toggle('light-logo', !!show && srcLight);
    img.hidden = !show;
    $('#drop-empty').hidden = !!show;
    if (show) img.src = processed.couleur;

    const notes = $('#sel-notes');
    notes.innerHTML = '';
    $('#src-clear').hidden = !hasSel();
    if (selError) {
      $('#scr-logo').textContent = 'Illisible';
      $('#scr-taille').textContent = '—';
      $('#src-name').textContent = 'Aucun logo chargé';
      notes.innerHTML = '<li>' + esc(MESSAGES[selError.code] || selError.message || 'Source illisible.') + '</li>';
    } else if (!hasSel()) {
      $('#scr-logo').textContent = 'Aucun';
      $('#scr-taille').textContent = '—';
      $('#src-name').textContent = 'Aucun logo chargé';
      if (sel && sel.lost) notes.innerHTML = '<li>Le logo source a disparu (document fermé ou logo supprimé) : glisse-le à nouveau.</li>';
    } else {
      const label = sel.name || plural(sel.count, 'objet', 'objets');
      $('#scr-logo').textContent = label + ' ' + (sel.colorSpace || '');
      $('#src-name').innerHTML = '<b>' + esc(label) + '</b>' + (sel.doc ? ', ' + esc(sel.doc) : '');
      $('#scr-taille').textContent = sel.w ? mm(sel.w) + ' × ' + mm(sel.h) + ' mm' : '—';
      const f = sel.flags || {};
      const list = [];
      if (f.raster) list.push('Contient une image : elle ne sera pas recolorée en noir, blanc ou uni.');
      if (f.mesh) list.push('Contient un filet de dégradé : il ne sera pas recoloré.');
      if (f.text && !st.outlineText) list.push('Les textes resteront éditables (vectorisation désactivée).');
      notes.innerHTML = list.map(t => '<li>' + esc(t) + '</li>').join('');
    }
  }

  function sameColor(a, b) {
    return !!a && !!b && (a.key && b.key ? a.key === b.key : (!a.key && !b.key && a.hex.toLowerCase() === b.hex.toLowerCase()));
  }

  function swatchHTML(c, removable, i) {
    const on = sameColor(st.brand, c);
    const label = c.label || c.hex.toUpperCase();
    const btn = '<button type="button" class="sw" data-src="' + (removable ? 'custom' : 'logo') + '" data-i="' + i +
      '" style="background:' + c.hex + '" aria-pressed="' + on + '" title="' + esc(label) + '" aria-label="' + esc(label) + '"></button>';
    if (!removable) return btn;
    return '<span class="sw-wrap">' + btn + '<button type="button" class="sw-del" data-i="' + i + '" title="Retirer" aria-label="Retirer ' + esc(label) + '">×</button></span>';
  }

  function logoColors() {
    return (sel && sel.colors ? sel.colors : []).filter(c => !c.white).slice(0, 8);
  }

  function renderBrand() {
    $('#brand-big').style.background = st.brand.hex;
    $('#brand-label').textContent = st.brand.label || '';
    $('#brand-hex').textContent = st.brand.hex.toUpperCase();
    const lc = logoColors();
    $('#sw-logo').innerHTML = lc.length ? lc.map((c, i) => swatchHTML(c, false, i)).join('') : '<span class="empty">Sélectionne un logo</span>';
    $('#sw-custom').innerHTML = st.customColors.map((c, i) => swatchHTML(c, true, i)).join('') +
      '<button type="button" class="sw-add" id="sw-add" aria-expanded="' + !$('#picker').hidden + '" aria-controls="picker" title="Choisir une couleur" aria-label="Choisir une couleur">+</button>';
  }

  /* Sélecteur de couleur intégré ------------------------------------- */

  let draft = { h: 0, s: 1, v: 1 };

  function hsvToHex(h, s, v) {
    const f = n => {
      const k = (n + h / 60) % 6;
      return Math.round(255 * (v - v * s * Math.max(0, Math.min(k, 4 - k, 1))));
    };
    return '#' + [f(5), f(3), f(1)].map(x => x.toString(16).padStart(2, '0')).join('');
  }

  function hexToHsv(hex) {
    const [r, g, b] = hexRGB(hex).map(x => x / 255);
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d) {
      if (mx === r) h = 60 * (((g - b) / d) % 6);
      else if (mx === g) h = 60 * ((b - r) / d + 2);
      else h = 60 * ((r - g) / d + 4);
    }
    return { h: (h + 360) % 360, s: mx ? d / mx : 0, v: mx };
  }

  function renderPicker(skipHex) {
    const hex = hsvToHex(draft.h, draft.s, draft.v);
    $('#sv').style.backgroundColor = hsvToHex(draft.h, 1, 1);
    $('#sv-handle').style.left = (draft.s * 100) + '%';
    $('#sv-handle').style.top = ((1 - draft.v) * 100) + '%';
    $('#sv-handle').style.background = hex;
    $('#hue-handle').style.left = (draft.h / 360 * 100) + '%';
    $('#hue-handle').style.background = hsvToHex(draft.h, 1, 1);
    $('#draft-dot').style.background = hex;
    if (!skipHex) $('#hex-input').value = hex.toUpperCase();
  }

  function openPicker(open) {
    $('#picker').hidden = !open;
    if (open) { draft = hexToHsv(st.brand.hex); renderPicker(); }
    const add = $('#sw-add');
    if (add) add.setAttribute('aria-expanded', String(open));
  }

  // Ajoute une couleur à « Mes couleurs » (sans doublon) et la sélectionne.
  function addCustom(c) {
    const color = { hex: c.hex.toLowerCase(), key: c.key || null, label: c.label || '' };
    st.customColors = st.customColors.filter(x => !sameColor(x, color));
    st.customColors.push(color);
    if (st.customColors.length > CUSTOM_MAX) st.customColors.shift();
    st.brand = Object.assign({}, color, { auto: false });
    changed({ thumbs: true });
  }

  function lightRow(rowId) {
    if (rowId === 'blanc') return true;
    if (rowId === 'mono') return luminance(st.brand.hex) > 0.8;
    if (rowId === 'couleur' || rowId === 'gris') return srcLight;
    return false;
  }

  function tileHTML(r, c) {
    const k = r.id + '|' + c.id;
    const title = r.long + ' ' + c.long;
    if (OFF.has(k)) {
      return '<span class="tile off" title="' + esc(title) + ' : invisible, même couleur que le fond"><span class="slot"></span></span>';
    }
    const on = st.cells.includes(k);
    const style = c.id === 'couleur' ? ' style="background:' + st.brand.hex + '"' : '';
    const dark = c.id === 'transparent' && lightRow(r.id) ? ' on-dark' : '';
    let img;
    if (!processed[r.id]) img = fallbackMark(r.id);
    else if (cssTint && r.id !== 'couleur') {
      const tint = { noir: '#000', blanc: '#fff', mono: st.brand.hex }[r.id];
      img = tint
        ? '<span class="tint" style="background:' + tint + ';-webkit-mask-image:url(&quot;' + processed[r.id] + '&quot;)"></span>'
        : '<img alt="" class="gray" src="' + processed[r.id] + '">';
    } else img = '<img alt="" src="' + processed[r.id] + '">';
    return '<button type="button" class="tile bg-' + c.id + dark + '" data-cell="' + k + '"' +
      ' aria-pressed="' + on + '" aria-label="' + esc(title) + '" title="' + esc(title) + '"><span class="face"' + style + '>' + img + '</span></button>';
  }

  function renderMatrix() {
    const lockTitle = st.lockBg ? 'Fonds verrouillés : clique pour les laisser modifiables' : 'Fonds modifiables : clique pour les verrouiller';
    let html = '<span></span>';
    html += '<button type="button" class="axis col" data-col="transparent" title="Tout basculer : sans fond">' + COL.transparent.label + '</button>';
    html += '<div class="col-head"><button type="button" class="axis col" data-col="couleur" title="Tout basculer : ' +
      esc(COL.couleur.long) + '">' + COL.couleur.label + '</button>' +
      '<button type="button" class="lock" id="lock-bg" aria-pressed="' + st.lockBg + '" title="' + lockTitle + '" aria-label="' + lockTitle + '">' +
      LOCK_ICON(st.lockBg) + '</button></div>';
    for (const r of ROWS) {
      const rowOn = COLS.some(c => st.cells.includes(r.id + '|' + c.id));
      html += '<button type="button" class="axis row' + (rowOn ? ' on' : '') + '" data-row="' + r.id +
        '" title="Tout basculer : ' + esc(r.long) + '">' + r.label + '</button>';
      html += COLS.map(c => tileHTML(r, c)).join('');
    }
    $('#matrix').innerHTML = html;
    renderOutput();
  }

  function renderNames() {
    const list = variants();
    const ol = $('#names');
    ol.innerHTML = list.length
      ? list.map(v => '<li title="' + esc(v.name) + '">' + esc(v.name) + '</li>').join('')
      : '<li class="empty">Coche des versions pour voir les noms des planches.</li>';
  }

  function meter(p) {
    const on = Math.round(Math.max(0, Math.min(1, p)) * METER_DOTS);
    // les points s'allument du bas vers le haut, comme un vumètre
    $$('#scr-meter i').forEach((el, i) => el.classList.toggle('on', METER_DOTS - 1 - i < on));
  }

  function status(text, tone) {
    const el = $('#scr-statut');
    el.textContent = text;
    el.className = tone || '';
  }

  // Écran de progression : grand pourcentage + segments qui s'allument.
  let shownPct = 0, pctAnim = null;
  function bars(p) {
    const on = Math.round(Math.max(0, Math.min(1, p)) * BARS);
    $$('#ld-bars i').forEach((el, i) => {
      el.style.transitionDelay = (Math.max(0, i - (on - 6)) * 12) + 'ms';
      el.classList.toggle('on', i < on);
    });
  }
  function countTo(target) {
    cancelAnimationFrame(pctAnim);
    const from = shownPct, t0 = performance.now(), dur = 320;
    const step = t => {
      const k = Math.min(1, (t - t0) / dur);
      shownPct = Math.round(from + (target - from) * (1 - Math.pow(1 - k, 3)));
      $('#ld-num').textContent = String(shownPct);
      if (k < 1) pctAnim = requestAnimationFrame(step);
    };
    pctAnim = requestAnimationFrame(step);
  }

  function progress(p, label) {
    const pct = Math.round(Math.max(0, Math.min(1, p)) * 100);
    const ld = $('#loader');
    ld.classList.remove('idle');
    ld.classList.toggle('done', pct >= 100);
    ld.setAttribute('aria-valuenow', String(pct));
    bars(p);
    countTo(pct);
    meter(p);
    if (label) $('#ld-label').textContent = label;
    status('Génération ' + pct + ' %', 'hot');
  }

  function resetProgress() {
    const ld = $('#loader');
    ld.classList.add('idle');
    ld.classList.remove('done');
    ld.setAttribute('aria-valuenow', '0');
    bars(0);
    cancelAnimationFrame(pctAnim);
    shownPct = 0;
    $('#ld-num').textContent = '0';
    $('#create-label').textContent = 'Générer';
    $('#out-hint').textContent = '';
  }

  // Laisse le panneau se redessiner avant qu'Illustrator ne soit occupé.
  const paint = () => new Promise(r => requestAnimationFrame(() => setTimeout(r, 40)));

  function renderOutput() {
    if (busy) return;
    const n = variants().length;
    const ready = hasSel() && n > 0;
    $('#create').disabled = !ready;
    $('#out-led').classList.toggle('on', ready);
    $('#scr-count').textContent = String(n).padStart(2, '0');
    let unit = n > 1 ? 'planches' : 'planche';
    if (sel && sel.w && n) {
      const pad = Math.max(0, Number(st.margin) || 0) / 100 * Math.min(sel.w, sel.h);
      unit += '\n' + mm(sel.w + 2 * pad) + ' × ' + mm(sel.h + 2 * pad) + ' mm';
    }
    $('#scr-unit').textContent = unit;
    meter(n / ALL_CELLS.length);
    if (!hasSel()) status('Glisse un logo', 'warn');
    else if (!n) status('Coche une version', 'warn');
    else status('Prêt', 'hot');
    if ($('#loader').classList.contains('idle')) {
      $('#ld-label').textContent = !hasSel() ? 'Glisse un logo' : !n ? 'Coche une version' : 'Prêt : ' + plural(n, 'planche', 'planches');
    }
  }

  function setSeg(id, v) {
    $$(id + ' button[data-v]').forEach(b => b.setAttribute('aria-checked', String(b.dataset.v === String(v))));
  }

  function renderKnob() {
    const v = Math.max(0, Math.min(MARGIN_MAX, Number(st.margin) || 0));
    const angle = -135 + (v / MARGIN_MAX) * 270;
    $('#knob-ptr').setAttribute('transform', 'rotate(' + angle.toFixed(1) + ' 32 32)');
    $$('#knob .ticks circle').forEach((c, i, all) => c.classList.toggle('on', i <= Math.round(v / MARGIN_MAX * (all.length - 1))));
    $('#knob').setAttribute('aria-valuenow', String(v));
    $('#margin-out').textContent = String(v);
  }

  function renderControls() {
    $('#client').value = st.client;
    $('#logo').value = st.logo;
    $('#pattern').value = st.pattern;
    renderKnob();
    setSeg('#white-mode', st.whiteMode);
    setSeg('#dest', st.dest);
    setSeg('#lang', st.lang);
    setSeg('#case', st.textCase);
    $('#outline-text').checked = st.outlineText;
    $('#ascii').checked = st.ascii;
    $('#settings').hidden = !st.settingsOpen;
    $('#settings-toggle').checked = st.settingsOpen;
    $('#version').textContent = 'v' + VERSION;
  }

  function renderFooter() {
    $('#remove').disabled = busy || !inventory;
    $('#refresh').disabled = busy;
    $('#scr-doc').textContent = inventory ? plural(inventory, 'planche', 'planches') : '—';
  }

  function renderAll() {
    renderProfiles();
    renderSource();
    renderBrand();
    renderMatrix();
    renderNames();
    renderFooter();
  }

  // Après une modification de réglage : on sauve et on redessine ce qui en dépend.
  function changed(opts = {}) {
    save();
    if (opts.thumbs) processThumbs();
    renderProfiles();
    if (opts.source) renderSource();
    renderBrand();
    renderMatrix();
    renderNames();
  }

  /* ---------------------------------------------------------------- */
  /* Comptes rendus                                                    */
  /* ---------------------------------------------------------------- */

  function errorText(r) {
    if (MESSAGES[r.code]) return MESSAGES[r.code];
    return 'Erreur Illustrator : ' + (r.message || r.code) + (r.line ? ' (ligne ' + r.line + ')' : '');
  }

  function warnText(code) {
    const [base, n] = String(code).split(':');
    if (base === 'RECOLOR_PARTIAL') return n + ' ' + WARNINGS.RECOLOR_PARTIAL;
    return WARNINGS[base] || code;
  }

  function report({ ok, errors = [], warnings = [] }) {
    let html = ok ? '<p class="ok">' + esc(ok) + '</p>' : '';
    for (const e of errors) html += '<p class="error">' + esc(e) + '</p>';
    const grouped = new Map();
    for (const w of warnings) {
      const key = w.code;
      if (!grouped.has(key)) grouped.set(key, []);
      if (w.name && !grouped.get(key).includes(w.name)) grouped.get(key).push(w.name);
    }
    for (const [code, names] of grouped) {
      html += '<p class="warn">' + esc(warnText(code)) + '</p>';
      if (names.length) html += '<ul>' + names.slice(0, 4).map(n => '<li>' + esc(n) + '</li>').join('') +
        (names.length > 4 ? '<li>et ' + (names.length - 4) + ' autres</li>' : '') + '</ul>';
    }
    $('#report').innerHTML = html;
    if (errors.length) status(errors.length > 1 ? errors.length + ' erreurs' : 'Erreur', 'warn');
    else if (warnings.length) status('Terminé, à vérifier', 'warn');
    else if (ok) status('Terminé', 'hot');
  }

  function setBusy(v) {
    busy = v;
    document.body.setAttribute('aria-busy', String(v));
    renderFooter();
    if (!v) renderOutput();
  }

  /* ---------------------------------------------------------------- */
  /* Profils                                                           */
  /* ---------------------------------------------------------------- */

  function snapshot() {
    const o = {};
    for (const k of PROFILE_FIELDS) o[k] = clone(st[k]);
    delete o.brand.auto;
    return o;
  }

  function isDirty() {
    const p = profiles.find(x => x.name === st.profile);
    if (!p) return false;
    const a = snapshot();
    return PROFILE_FIELDS.some(k => {
      const pv = clone(p[k] === undefined ? DEFAULTS[k] : p[k]);
      if (k === 'brand') delete pv.auto;
      return JSON.stringify(pv) !== JSON.stringify(a[k]);
    });
  }

  async function loadProfiles() {
    const r = await api('profilesRead');
    if (!r.ok) { profiles = []; return; }
    try {
      const data = JSON.parse(r.json || '[]');
      profiles = Array.isArray(data) ? data.filter(p => p && p.name) : [];
    } catch (e) { profiles = []; }
  }

  async function writeProfiles() {
    profiles.sort((a, b) => a.name.localeCompare(b.name, 'fr'));
    const r = await api('profilesWrite', { json: JSON.stringify(profiles, null, 2) });
    if (!r.ok) report({ errors: [errorText(r)] });
    return r.ok;
  }

  function applyProfile(p) {
    for (const k of PROFILE_FIELDS) if (p[k] !== undefined) st[k] = clone(p[k]);
    st.brand = Object.assign({}, DEFAULTS.brand, st.brand, { auto: false });
    st.cells = sanitizeCells(st.cells);
    st.profile = p.name;
    renderControls();
    changed({ thumbs: true, source: true });
  }

  async function saveProfile() {
    const name = (st.client || '').trim() || st.profile || 'Sans nom';
    const p = Object.assign({ name }, snapshot(), { saved: new Date().toISOString() });
    const i = profiles.findIndex(x => x.name === name);
    if (i >= 0) profiles[i] = p; else profiles.push(p);
    st.profile = name;
    st.brand.auto = false;
    save();
    if (await writeProfiles()) report({ ok: 'Profil « ' + name + ' » enregistré.' });
    renderProfiles();
  }

  let delTimer = null;
  async function deleteProfile() {
    const btn = $('#profile-del');
    if (!st.profile) return;
    if (!btn.classList.contains('armed')) {
      btn.classList.add('armed');
      btn.title = 'Cliquer encore pour supprimer « ' + st.profile + ' »';
      clearTimeout(delTimer);
      delTimer = setTimeout(() => { btn.classList.remove('armed'); btn.title = 'Supprimer ce profil'; }, 3000);
      return;
    }
    btn.classList.remove('armed');
    const name = st.profile;
    profiles = profiles.filter(p => p.name !== name);
    st.profile = '';
    save();
    if (await writeProfiles()) report({ ok: 'Profil « ' + name + ' » supprimé.' });
    renderProfiles();
  }

  /* ---------------------------------------------------------------- */
  /* Actions                                                           */
  /* ---------------------------------------------------------------- */

  function pickDominant(colors) {
    const sat = hex => {
      const [r, g, b] = hexRGB(hex).map(v => v / 255);
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
      return mx === 0 ? 0 : (mx - mn) / mx;
    };
    const usable = colors.filter(c => !c.white);
    return usable.find(c => sat(c.hex) > 0.18) || usable[0] || null;
  }

  let refreshing = false;
  async function refresh(force) {
    if (busy || refreshing) return;
    refreshing = true;
    const icon = $('#refresh');
    icon.classList.remove('spin');
    void icon.offsetWidth;
    if (force) icon.classList.add('spin');
    try {
      const info = await api('sourceInfo');
      if (!info.ok) {
        sel = null;
        selError = info;
        thumbSig = ''; thumbImg = null; processed = {};
      } else {
        selError = null;
        sel = info;
        if (st.brand.auto && info.colors && info.colors.length) {
          const d = pickDominant(info.colors);
          if (d) { st.brand = { hex: d.hex, key: d.key, label: d.label, auto: true }; save(); }
        }
        const sig = info.count ? [info.doc, info.count, (info.w || 0).toFixed(2), (info.h || 0).toFixed(2),
          (info.colors || []).map(c => c.key).join(';')].join('|') : '';
        if (!sig) { thumbSig = ''; thumbImg = null; processed = {}; }
        else if (force || sig !== thumbSig) { thumbSig = sig; if (!force) thumbRetry = 0; loadThumb(); }
      }
      const inv = await api('inventory');
      inventory = inv.ok ? inv.count : 0;
      inventoryBgs = inv.ok ? (inv.bgs || 0) : 0;
    } finally {
      refreshing = false;
      renderAll();
    }
  }

  async function create() {
    const list = variants();
    if (!list.length || busy) return;
    $('#report').innerHTML = '';
    setBusy(true);
    $('#create').disabled = true;
    $('#out-led').classList.add('on', 'blink');
    $('#create-label').textContent = 'Préparation';
    $('#out-hint').textContent = 'Illustrator travaille : ne touche à rien pendant quelques secondes.';
    progress(0.02, 'Préparation');
    await paint();
    let done = false;
    try {
      const prep = await api('prepare', {
        variants: list,
        margin: Number(st.margin) || 0,
        outlineText: st.outlineText,
        dest: st.dest,
        whiteMode: st.whiteMode,
        brand: { hex: st.brand.hex, key: st.brand.key },
        lockBg: st.lockBg
      });
      if (!prep.ok) { report({ errors: [errorText(prep)] }); return; }

      const warnings = [], errors = [];
      for (let i = 0; i < prep.count; i++) {
        $('#scr-count').textContent = String(i + 1).padStart(2, '0');
        $('#create-label').textContent = 'Génération';
        progress(0.08 + 0.86 * (i / prep.count), 'Planche ' + (i + 1) + ' sur ' + prep.count);
        await paint();
        const r = await api('build', { i });
        if (!r.ok) errors.push(prep.names[i] + ' : ' + errorText(r));
        else (r.warnings || []).forEach(code => warnings.push({ code, name: r.name }));
      }
      progress(0.96, 'Finition');
      await paint();
      const fin = await api('finish');
      progress(1, plural(prep.count - errors.length, 'planche créée', 'planches créées'));
      done = true;
      $('#create-label').textContent = 'Terminé';
      $('#out-hint').textContent = '';
      const made = prep.count - errors.length;
      report({
        ok: made ? plural(made, 'planche générée', 'planches générées') + (fin && fin.created ? ' dans un nouveau document.' : '.') : '',
        errors, warnings
      });
    } finally {
      $('#out-led').classList.remove('blink');
      if (!done) { resetProgress(); }
      const keep = $('#scr-statut').textContent;
      const tone = $('#scr-statut').className;
      setBusy(false);
      await refresh(false);
      status(keep, tone);
      setTimeout(() => { if (!busy) { resetProgress(); renderOutput(); } }, done ? 2500 : 0);
    }
  }

  let armTimer = null;
  async function removeAll() {
    const btn = $('#remove');
    if (!btn.classList.contains('armed')) {
      btn.classList.add('armed');
      btn.textContent = 'Confirmer : effacer ' + plural(inventory, 'planche', 'planches');
      clearTimeout(armTimer);
      armTimer = setTimeout(disarm, 4000);
      return;
    }
    disarm();
    setBusy(true);
    try {
      const r = await api('removeAll');
      if (!r.ok) report({ errors: [errorText(r)] });
      else report({ ok: plural(r.variants, 'planche effacée', 'planches effacées') + '.' });
    } finally {
      setBusy(false);
      refresh(false);
    }
  }
  function disarm() {
    const btn = $('#remove');
    btn.classList.remove('armed');
    btn.textContent = 'Effacer les planches de ce document';
    clearTimeout(armTimer);
  }

  // Cadenas au-dessus de la colonne « Fond coloré » : pour les prochaines planches,
  // et appliqué tout de suite aux fonds déjà créés dans le document.
  async function toggleLock() {
    st.lockBg = !st.lockBg;
    save();
    renderMatrix();
    if (inventoryBgs > 0 && !busy) {
      const r = await api('setBgLock', { locked: st.lockBg });
      if (r.ok) report({ ok: st.lockBg ? 'Fonds verrouillés.' : 'Fonds déverrouillés : tu peux les modifier.' });
      else report({ errors: [errorText(r)] });
    }
  }

  // Le logo sélectionné dans Illustrator devient la source (bouton, ou logo glissé depuis le document).
  async function loadSelection(origin) {
    if (busy) return;
    setBusy(true);
    try {
      const r = await api('setSource');
      if (!r.ok) {
        report({ errors: [r.code === 'NO_SELECTION' && origin === 'file' ? MESSAGES.BAD_FILE : errorText(r)] });
        return;
      }
      report({ ok: 'Logo chargé : ' + (r.name || plural(r.count, 'objet', 'objets')) + '.' });
    } finally {
      setBusy(false);
      thumbRetry = 0;
      refresh(true);
    }
  }

  // Fichier déposé : copié dans le dossier temporaire puis importé dans Illustrator.
  async function importFile(file) {
    if (!file || busy) return;
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    if (!VECTOR_EXT.includes(ext)) { report({ errors: [MESSAGES.BAD_FILE] }); return; }
    setBusy(true);
    try {
      const b64 = await new Promise((resolve, reject) => {
        const fr = new FileReader();
        fr.onload = () => resolve(String(fr.result).split(',')[1] || '');
        fr.onerror = reject;
        fr.readAsDataURL(file);
      });
      const tmp = await api('tempFolder');
      if (!tmp.ok) { report({ errors: [errorText(tmp)] }); return; }
      const path = tmp.path.replace(/\\/g, '/') + '/batch_import_' + Date.now() + '.' + ext;
      if (IN_CEP) {
        const w = window.cep.fs.writeFile(path, b64, window.cep.encoding.Base64);
        if (w.err) { report({ errors: [MESSAGES.WRITE_FAIL] }); return; }
      }
      const base = file.name.replace(/\.[^.]+$/, '');
      const r = await api('placeFile', { path, name: base });
      if (!r.ok) { report({ errors: [errorText(r)] }); return; }
      report({ ok: 'Logo chargé : ' + base + (r.created ? ' (nouveau document).' : '.') });
    } catch (e) {
      report({ errors: [MESSAGES.WRITE_FAIL] });
    } finally {
      setBusy(false);
      thumbRetry = 0;
      setTimeout(() => refresh(true), 200);
    }
  }

  /* ---------------------------------------------------------------- */
  /* Événements                                                        */
  /* ---------------------------------------------------------------- */

  function toggleCells(keys) {
    const usable = keys.filter(k => !OFF.has(k));
    const allOn = usable.every(k => st.cells.includes(k));
    st.cells = allOn ? st.cells.filter(k => !usable.includes(k)) : Array.from(new Set(st.cells.concat(usable)));
  }

  function bind() {
    $('#matrix').addEventListener('click', e => {
      const t = e.target.closest('button');
      if (!t) return;
      if (t.id === 'lock-bg') { toggleLock(); return; }
      if (t.dataset.cell) toggleCells([t.dataset.cell]);
      else if (t.dataset.row) toggleCells(COLS.map(c => t.dataset.row + '|' + c.id));
      else if (t.dataset.col) toggleCells(ROWS.map(r => r.id + '|' + t.dataset.col));
      else return;
      changed();
    });

    $$('[data-preset]').forEach(b => b.addEventListener('click', () => {
      const p = b.dataset.preset;
      st.cells = p === 'essentiel' ? ESSENTIEL.slice() : p === 'tout' ? ALL_CELLS.slice() : [];
      changed();
    }));

    // Profils : menu déroulant maison
    const ddBtn = $('#profile-btn'), ddMenu = $('#profile-menu');
    let active = -1;
    const items = () => $$('#profile-menu li');
    const setActive = i => {
      const list = items();
      active = Math.max(0, Math.min(list.length - 1, i));
      list.forEach((li, k) => li.classList.toggle('active', k === active));
      if (list[active]) { ddMenu.setAttribute('aria-activedescendant', list[active].id); list[active].scrollIntoView({ block: 'nearest' }); }
    };
    const openMenu = open => {
      ddMenu.hidden = !open;
      ddBtn.setAttribute('aria-expanded', String(open));
      if (open) {
        const list = items();
        setActive(Math.max(0, list.findIndex(li => li.getAttribute('aria-selected') === 'true')));
        ddMenu.focus();
      }
    };
    const choose = name => {
      openMenu(false);
      ddBtn.focus();
      const p = profiles.find(x => x.name === name);
      if (p) applyProfile(p);
      else { st.profile = ''; save(); renderProfiles(); }
    };
    ddBtn.addEventListener('click', () => openMenu(ddMenu.hidden));
    ddBtn.addEventListener('keydown', e => { if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); openMenu(true); } });
    ddMenu.addEventListener('click', e => { const li = e.target.closest('li'); if (li) choose(li.dataset.name); });
    ddMenu.addEventListener('mousemove', e => { const li = e.target.closest('li'); if (li) setActive(items().indexOf(li)); });
    ddMenu.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') { e.preventDefault(); setActive(active + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(active - 1); }
      else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); const li = items()[active]; if (li) choose(li.dataset.name); }
      else if (e.key === 'Escape' || e.key === 'Tab') { openMenu(false); ddBtn.focus(); }
    });
    document.addEventListener('pointerdown', e => { if (!ddMenu.hidden && !$('#profile-dd').contains(e.target)) openMenu(false); });
    $('#profile-save').addEventListener('click', saveProfile);
    $('#profile-del').addEventListener('click', deleteProfile);

    // Couleur de marque : cliquer une pastille la sélectionne sans rien retirer.
    const pickSwatch = e => {
      const del = e.target.closest('.sw-del');
      if (del) {
        const c = st.customColors[Number(del.dataset.i)];
        st.customColors.splice(Number(del.dataset.i), 1);
        if (sameColor(st.brand, c)) {
          // la couleur retirée était active : on revient à la couleur dominante du logo
          const d = pickDominant(sel && sel.colors ? sel.colors : []);
          st.brand = d ? { hex: d.hex, key: d.key, label: d.label, auto: true } : Object.assign({}, st.brand, { auto: true });
        }
        changed({ thumbs: true });
        return;
      }
      if (e.target.closest('#sw-add')) { openPicker($('#picker').hidden); return; }
      const b = e.target.closest('.sw');
      if (!b) return;
      const c = b.dataset.src === 'custom' ? st.customColors[Number(b.dataset.i)] : logoColors()[Number(b.dataset.i)];
      if (!c) return;
      st.brand = { hex: c.hex, key: c.key || null, label: c.label || '', auto: false };
      changed({ thumbs: true });
    };
    $('#sw-logo').addEventListener('click', pickSwatch);
    $('#sw-custom').addEventListener('click', pickSwatch);

    // Carré saturation / luminosité et barre de teinte
    const drag2d = (el, onMove) => {
      const move = e => {
        const r = el.getBoundingClientRect();
        onMove(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)), Math.max(0, Math.min(1, (e.clientY - r.top) / r.height)));
        renderPicker();
      };
      el.addEventListener('pointerdown', e => { el.setPointerCapture(e.pointerId); move(e); el.addEventListener('pointermove', move); });
      el.addEventListener('pointerup', () => el.removeEventListener('pointermove', move));
    };
    drag2d($('#sv'), (x, y) => { draft.s = x; draft.v = 1 - y; });
    drag2d($('#hue'), x => { draft.h = Math.min(359.9, x * 360); });
    $('#sv').addEventListener('keydown', e => {
      const k = { ArrowLeft: ['s', -0.02], ArrowRight: ['s', 0.02], ArrowUp: ['v', 0.02], ArrowDown: ['v', -0.02] }[e.key];
      if (!k) return;
      e.preventDefault();
      draft[k[0]] = Math.max(0, Math.min(1, draft[k[0]] + k[1]));
      renderPicker();
    });
    $('#hue').addEventListener('keydown', e => {
      const d = { ArrowLeft: -3, ArrowRight: 3 }[e.key];
      if (!d) return;
      e.preventDefault();
      draft.h = (draft.h + d + 360) % 360;
      renderPicker();
    });
    $('#hex-input').addEventListener('input', e => {
      const v = e.target.value.trim().replace(/^#?/, '#');
      if (/^#[0-9a-f]{6}$/i.test(v) || /^#[0-9a-f]{3}$/i.test(v)) { draft = hexToHsv(v); renderPicker(true); }
    });
    $('#picker-add').addEventListener('click', () => { addCustom({ hex: hsvToHex(draft.h, draft.s, draft.v) }); openPicker(false); });
    $('#picker-close').addEventListener('click', () => openPicker(false));

    // Couleurs venues d'Illustrator : valeurs exactes (CMJN, Pantone…)
    const fromIllustrator = async (fn, args) => {
      const r = await api(fn, args);
      if (r.ok) { addCustom(r); openPicker(false); report({ ok: 'Couleur ajoutée : ' + (r.label || r.hex.toUpperCase()) + '.' }); }
      else if (r.code !== 'CANCELLED') report({ errors: [errorText(r)] });
    };
    $('#pick-ai').addEventListener('click', () => fromIllustrator('pickColor', { hex: hsvToHex(draft.h, draft.s, draft.v), key: null }));
    $('#pick-fill').addEventListener('click', () => fromIllustrator('fillColor'));
    if ('EyeDropper' in window) {
      $('#pick-eye').hidden = false;
      $('#pick-eye').addEventListener('click', async () => {
        try { const r = await new window.EyeDropper().open(); draft = hexToHsv(r.sRGBHex); renderPicker(); } catch (e) { /* annulé */ }
      });
    }

    // Noms
    const text = (id, key) => $(id).addEventListener('input', e => { st[key] = e.target.value; changed(); });
    text('#client', 'client');
    text('#logo', 'logo');
    text('#pattern', 'pattern');
    $$('.tokens [data-token]').forEach(b => b.addEventListener('click', () => {
      const input = $('#pattern');
      const s = input.selectionStart ?? input.value.length, en = input.selectionEnd ?? input.value.length;
      input.value = input.value.slice(0, s) + b.dataset.token + input.value.slice(en);
      st.pattern = input.value;
      changed();
      input.focus();
      input.setSelectionRange(s + b.dataset.token.length, s + b.dataset.token.length);
    }));
    $('#pattern-reset').addEventListener('click', () => { st.pattern = DEFAULT_PATTERN; $('#pattern').value = st.pattern; changed(); });

    // Réglages (fenêtre repliable)
    $('#settings-toggle').addEventListener('change', e => { st.settingsOpen = e.target.checked; save(); renderControls(); });
    const seg = (id, key, opts) => $(id).addEventListener('click', e => {
      const b = e.target.closest('button[data-v]');
      if (!b) return;
      st[key] = b.dataset.v;
      setSeg(id, st[key]);
      changed(opts);
    });
    seg('#white-mode', 'whiteMode', { thumbs: true });
    seg('#dest', 'dest');
    seg('#lang', 'lang');
    seg('#case', 'textCase');
    $('#outline-text').addEventListener('change', e => { st.outlineText = e.target.checked; changed({ source: true }); });
    $('#ascii').addEventListener('change', e => { st.ascii = e.target.checked; changed(); });

    // Potentiomètre de marge : glisser vers le haut ou le bas, molette, flèches, double-clic = 10 %
    const knob = $('#knob');
    const setMargin = v => {
      const nv = Math.max(0, Math.min(MARGIN_MAX, Math.round(v)));
      if (nv === st.margin) return;
      st.margin = nv;
      renderKnob();
      changed();
    };
    let drag = null;
    knob.addEventListener('pointerdown', e => { drag = { y: e.clientY, v: st.margin }; knob.setPointerCapture(e.pointerId); });
    knob.addEventListener('pointermove', e => { if (drag) setMargin(drag.v + (drag.y - e.clientY) / 3); });
    knob.addEventListener('pointerup', () => { drag = null; });
    knob.addEventListener('wheel', e => { e.preventDefault(); setMargin(st.margin + (e.deltaY < 0 ? 1 : -1)); }, { passive: false });
    knob.addEventListener('dblclick', () => setMargin(10));
    knob.addEventListener('keydown', e => {
      if (e.key === 'ArrowUp' || e.key === 'ArrowRight') { e.preventDefault(); setMargin(st.margin + 1); }
      if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') { e.preventDefault(); setMargin(st.margin - 1); }
    });
    // couronne de points autour du potentiomètre
    const ticks = [];
    for (let i = 0; i <= 20; i++) {
      const a = (-135 + i * 13.5) * Math.PI / 180;
      ticks.push('<circle cx="' + (32 + Math.sin(a) * 27).toFixed(2) + '" cy="' + (32 - Math.cos(a) * 27).toFixed(2) + '" r="' + (i % 5 === 0 ? 1.4 : 0.9) + '"/>');
    }
    $('#knob .ticks').innerHTML = ticks.join('');
    renderKnob();

    // Source : uniquement par glisser-déposer (ou le bouton « Charger la sélection »).
    const drop = $('#drop');
    ['dragover', 'drop'].forEach(ev => window.addEventListener(ev, e => e.preventDefault()));
    drop.addEventListener('dragenter', e => { e.preventDefault(); drop.classList.add('dragging'); });
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('dragging'); });
    drop.addEventListener('dragleave', e => { if (!drop.contains(e.relatedTarget)) drop.classList.remove('dragging'); });
    drop.addEventListener('drop', e => {
      e.preventDefault();
      drop.classList.remove('dragging');
      const f = e.dataTransfer && e.dataTransfer.files ? e.dataTransfer.files[0] : null;
      const ext = f ? (f.name.split('.').pop() || '').toLowerCase() : '';
      if (f && VECTOR_EXT.includes(ext)) importFile(f);
      else loadSelection(f ? 'file' : 'drag');   // logo glissé depuis le document Illustrator
    });
    $('#src-load').addEventListener('click', () => loadSelection('button'));
    $('#src-clear').addEventListener('click', async () => {
      await api('clearSource');
      thumbSig = ''; thumbImg = null; processed = {};
      refresh(true);
    });

    $('#create').addEventListener('click', create);
    $('#remove').addEventListener('click', removeAll);
    $('#refresh').addEventListener('click', () => refresh(true));

    // Pas de lecture automatique au survol : la source est mémorisée.
    if (IN_CEP) {
      ['documentAfterActivate', 'documentAfterDeactivate'].forEach(ev => {
        try { host.addEventListener(ev, () => { if (!busy) refresh(false); }); } catch (e) { /* événement indisponible */ }
      });
    }
  }

  /* ---------------------------------------------------------------- */
  /* Faux moteur pour prévisualiser le panneau hors d'Illustrator      */
  /* ---------------------------------------------------------------- */

  const Mock = {
    inv: 0,
    hasSel: false,
    logo() {
      if (this._logo) return this._logo;
      const c = document.createElement('canvas');
      c.width = 220; c.height = 80;
      const x = c.getContext('2d');
      x.fillStyle = '#e4002b'; x.beginPath(); x.arc(40, 40, 36, 0, Math.PI * 2); x.fill();
      x.fillStyle = '#ffffff'; x.font = 'bold 44px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('Ü', 40, 43);
      x.fillStyle = '#141414'; x.font = 'bold 36px Arial'; x.textAlign = 'left'; x.fillText('sürpriz', 86, 42);
      this._logo = c.toDataURL();
      return this._logo;
    },
    eval(code) {
      const m = code.match(/api\("(\w+)","([^"]*)"\)/);
      const name = m ? m[1] : '';
      const args = m && m[2] ? JSON.parse(decodeURIComponent(m[2])) : {};
      const ok = o => JSON.stringify(Object.assign({ ok: true }, o));
      switch (name) {
        case 'setSource': this.hasSel = true; return Mock.eval('api("sourceInfo","")');
        case 'clearSource': this.hasSel = false; return ok({});
        case 'sourceInfo':
          if (!this.hasSel) return ok({ count: 0, colors: [] });
          if (name === 'sourceInfo') return ok({ count: 1, name: 'logo_surpriz', doc: 'surpriz_logo.ai', colorSpace: 'RGB', w: 340.2, h: 113.4,
            colors: [
              { key: 'RGB:20,20,20', hex: '#141414', white: false, label: 'R20 V20 B20' },
              { key: 'RGB:228,0,43', hex: '#e4002b', white: false, label: 'R228 V0 B43' },
              { key: 'RGB:255,255,255', hex: '#ffffff', white: true, label: 'R255 V255 B255' }
            ], flags: { text: true } });
          return ok({ count: 3, doc: 'surpriz_logo.ai', colorSpace: 'RGB', w: 340.2, h: 113.4,
            colors: [
              { key: 'RGB:20,20,20', hex: '#141414', white: false, label: 'R20 V20 B20' },
              { key: 'RGB:228,0,43', hex: '#e4002b', white: false, label: 'R228 V0 B43' },
              { key: 'SPOT:PANTONE 7739 C|100', hex: '#319b42', white: false, label: 'PANTONE 7739 C' },
              { key: 'RGB:255,255,255', hex: '#ffffff', white: true, label: 'R255 V255 B255' }
            ],
            flags: { text: true } });
        case 'thumbnail': return ok({ dataUrl: this.logo() });
        case 'inventory': return ok({ count: this.inv, bgs: this.inv ? 1 : 0 });
        case 'setBgLock': return ok({ count: 1, locked: args.locked });
        case 'prepare': this.count = args.variants.length; this.names = args.variants.map(v => v.name); return ok({ count: this.count, names: this.names });
        case 'build': return ok({ name: this.names[args.i], warnings: args.i === 1 ? ['RECOLOR_PARTIAL:2'] : [] });
        case 'finish': this.inv = this.count; return ok({ created: false });
        case 'removeAll': { const n = this.inv; this.inv = 0; return ok({ variants: n, artboards: n }); }
        case 'tempFolder': return ok({ path: '/tmp' });
        case 'placeFile': this.hasSel = true; return ok({ created: false });
        case 'pickColor': return ok({ key: 'CMYK:0,60,100,0', hex: '#ff6600', label: 'C0 M60 J100 N0' });
        case 'fillColor': return ok({ key: 'SPOT:PANTONE 2728 C|100', hex: '#0047bb', label: 'PANTONE 2728 C' });
        case 'profilesRead': return ok({ json: localStorage.getItem('mock.profiles') || '[]' });
        case 'profilesWrite': localStorage.setItem('mock.profiles', args.json); return ok({});
        default: return ok({});
      }
    }
  };
  window.__logopackMock = Mock;

  /* ---------------------------------------------------------------- */

  $('#scr-meter').innerHTML = '<i></i>'.repeat(METER_DOTS);
  $('#ld-bars').innerHTML = '<i></i>'.repeat(BARS);
  resetProgress();
  renderControls();
  bind();
  renderAll();
  loadProfiles().then(() => { renderProfiles(); refresh(true); });
})();
